package com.example.employeeIntroduction.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.employeeIntroduction.dto.AssignmentRequest;
import com.example.employeeIntroduction.dto.AssignmentUpdateRequest;
import com.example.employeeIntroduction.dto.EmployeeRequest;
import com.example.employeeIntroduction.dto.EmployeeUpdateRequest;
import com.example.employeeIntroduction.entity.Assignment;
import com.example.employeeIntroduction.entity.Department;
import com.example.employeeIntroduction.entity.Employee;
import com.example.employeeIntroduction.entity.Group;
import com.example.employeeIntroduction.entity.License;
import com.example.employeeIntroduction.entity.Post;
import com.example.employeeIntroduction.repository.AssignmentRepository;
import com.example.employeeIntroduction.repository.DepartmentRepository;
import com.example.employeeIntroduction.repository.EmployeeRepository;
import com.example.employeeIntroduction.repository.GroupRepository;
import com.example.employeeIntroduction.repository.LicenseRepository;
import com.example.employeeIntroduction.repository.PostRepository;

/**
 * 社員情報に関連するビジネスロジックを提供するサービスクラスです。
 * データベースからの情報の取得、登録、更新、削除などの操作を行います。
 */

@Service
@Transactional(rollbackFor = Exception.class)
public class EmployeeService {

	//各リポジトリをインスタンス化

	@Autowired
	private LicenseRepository licenseRepository;

	@Autowired
	private final EmployeeRepository employeeRepository;
	private final AssignmentRepository assignmentRepository;
	private final DepartmentRepository departmentRepository;
	private final GroupRepository groupRepository;
	private final PostRepository postRepository;

	public EmployeeService(
			AssignmentRepository assignmentRepository,
			EmployeeRepository employeeRepository, GroupRepository groupRepository,
			DepartmentRepository departmentRepository, PostRepository postRepository) {

		this.assignmentRepository = assignmentRepository;
		this.employeeRepository = employeeRepository;
		this.departmentRepository = departmentRepository;
		this.groupRepository = groupRepository;
		this.postRepository = postRepository;

	}

	/**
	 *DBから部署情報を全件取得するメソッド。
	 *
	 * @author 中村優介
	 * @return 取得した部署情報
	 * 
	 */

	public Iterable<Department> catchAll() {
		return departmentRepository.findAll();
	}

	/**
	 *DBからグループ情報を全件取得するメソッド。
	 *
	 * @author 中村優介
	 * @return 取得したグループ情報
	 * 
	 */

	public Iterable<Group> findAll() {
		return groupRepository.findAll();
	}

	/**
	 *DBから役職情報を全件取得するメソッド。
	 *
	 * @author 中村優介
	 * @return 取得し役職情報
	 * 
	 */

	public Iterable<Post> getAll() {
		return postRepository.findAll();
	}

	/**
	 *DBから配属情報を全件取得するメソッド。
	 *
	 * @author 中村優介
	 * @return 取得した配属情報
	 * 
	 */

	public Iterable<Assignment> findAssignmentAll() {
		return assignmentRepository.findAll();
	}

	/**
	  * DBに画面からの社員情報および配属情報を登録するメソッド。
	  * 
	  * @author 中村優介
	  * @param employeeRequest 画面から入力された社員情報
	  * @param assignmentRequest 画面から入力された配属情報
	  * 
	  */

	@Transactional
	public void insert(EmployeeRequest employeeRequest, AssignmentRequest assignmentRequest) {

		//登録情報を格納するオブジェクトを生成
		Employee employee = new Employee();

		Assignment assignment = new Assignment();

		Date now = new Date();

		//Employeeの情報を設定

		//社員番号
		employee.setEmployee_number(employeeRequest.getEmployee_number());

		//氏名
		employee.setName(employeeRequest.getName());

		//氏名（かな）
		employee.setName_ruby(employeeRequest.getName_ruby());

		//氏名（ローマ字）
		employee.setName_alphabet(employeeRequest.getName_alphabet());

		//開発経験年数
		employee.setExperience_year(employeeRequest.getExperience_year());

		//社内メールアドレス
		employee.setE_mail(employeeRequest.getE_mail());

		//電話番号
		employee.setPhone_number(employeeRequest.getPhone_number());

		//生年月日
		employee.setBirth_date(employeeRequest.getBirth_date());

		//入社年月
		employee.setEntry_date(employeeRequest.getEntry_date());

		//資格
		employee.setAcquiredLicense(employeeRequest.getAcquired_license());

		//習得言語
		employee.setAcquiredLanguage(employeeRequest.getAcquired_language());

		//習得ミドルウェア
		employee.setAcquiredMiddleware(employeeRequest.getAcquired_middleware());

		//趣味
		employee.setHobby(employeeRequest.getHobby());

		//特技
		employee.setTalent(employeeRequest.getTalent());

		//自己紹介
		employee.setSelf_introduction(employeeRequest.getSelf_introduction());

		//写真
		employee.setPhoto_path(employeeRequest.getPhoto_path());

		//権限番号
		employee.setAuthority_id(employeeRequest.getAuthority_id());

		//新卒ステータス
		employee.setNew_graduate_status(employeeRequest.getNew_graduate_status());

		//雇用形態
		employee.setEmployment_status(employeeRequest.getEmployment_status());

		//在職ステータス
		employee.setTenure_status(employeeRequest.getTenure_status());

		//登録者
		employee.setInsert_person(employeeRequest.getInsert_person());

		//更新者
		employee.setUpdate_person(employeeRequest.getUpdate_person());

		//削除者
		employee.setDelete_person(employeeRequest.getDelete_person());

		//登録日時
		employee.setInsert_date(now);

		//更新日時
		employee.setUpdate_date(now);

		//削除日時
		employee.setDelete_date(now);

		//退職日時
		employee.setRetirement_date(now);

		// Employeeを保存してIDを取得
		employeeRepository.save(employee);

		// Assignmentの情報を設定

		//所属番号
		assignment.setAssignmentId(assignmentRequest.getAssignment_id());

		//社員ID
		assignment.setEmployeeId(employee.getEmployee_id()); // 生成されたIDを使用

		//部署番号
		assignment.setDepartmentId(assignmentRequest.getDepartment_id());

		//グループ番号
		assignment.setGroupId(assignmentRequest.getGroup_id());

		//役職番号
		assignment.setPostId(assignmentRequest.getPost_id());

		//登録者
		assignment.setInsertPerson(assignmentRequest.getInsert_person());

		//更新者
		assignment.setUpdatePerson(assignmentRequest.getUpdate_person());

		//削除者
		assignment.setDeletePerson(assignmentRequest.getDelete_person());

		//登録日時
		assignment.setInsertDate(now);

		//更新日時
		assignment.setUpdateDate(now);

		//削除日時
		assignment.setDeleteDate(now);

		// Assignmentを保存
		assignmentRepository.save(assignment);

	}

	/**
	 *DBから社員情報を全件取得するメソッド。
	 *
	 * @author 中村優介
	 * @return 取得した社員情報
	 * 
	 */

	public Iterable<Employee> searchAll() {
		return employeeRepository.findAll();
	}

	/**
	 * 指定された社員IDで社員情報を取得するメソッド。
	 *
	 * @author 中村優介
	 * @param employee_id 取得する社員のID
	 * @return 取得した社員情報
	 * @throws IllegalArgumentException 社員が見つからない場合
	 * 
	 */

	public Employee findById(Integer employee_id) {

		//リポジトリ経由でDBから社員情報を1件取得して返す
		return employeeRepository.findById(employee_id)
				.orElseThrow(() -> new IllegalArgumentException("Employee not found"));

	}

	/**
	  * DBに社員情報および所属情報を更新するメソッド。
	  * 
	  * @author 中村優介
	  * @param employeeUpdateRequest　更新用の社員情報
	  * @param assignmentUpdateRequest　更新用の配属情報
	  * 
	  */

	public void update(EmployeeUpdateRequest employeeUpdateRequest, AssignmentUpdateRequest assignmentUpdateRequest) {

		//findByIdメソッドで更新する情報を取得
		Employee employee = findById(employeeUpdateRequest.getEmployee_id());

		//更新情報を格納するオブジェクトを生成
		Assignment assignment = new Assignment();

		Date now = new Date();

		//更新された各情報を格納
		employee.setEmployee_id(employeeUpdateRequest.getEmployee_id());

		//社員番号
		employee.setEmployee_number(employeeUpdateRequest.getEmployee_number());

		//氏名
		employee.setName(employeeUpdateRequest.getName());

		//氏名（かな）
		employee.setName_ruby(employeeUpdateRequest.getName_ruby());

		//氏名（ローマ字）
		employee.setName_alphabet(employeeUpdateRequest.getName_alphabet());

		//開発経験年数
		employee.setExperience_year(employeeUpdateRequest.getExperience_year());

		//社内メールアドレス
		employee.setE_mail(employeeUpdateRequest.getE_mail());

		//電話番号
		employee.setPhone_number(employeeUpdateRequest.getPhone_number());

		//生年月日
		employee.setBirth_date(employeeUpdateRequest.getBirth_date());

		//入社年月
		employee.setEntry_date(employeeUpdateRequest.getEntry_date());

		//資格
		employee.setAcquiredLicense(employeeUpdateRequest.getAcquired_license());

		//習得言語
		employee.setAcquiredLanguage(employeeUpdateRequest.getAcquired_language());

		//習得ミドルウェア
		employee.setAcquiredMiddleware(employeeUpdateRequest.getAcquired_middleware());

		//趣味
		employee.setHobby(employeeUpdateRequest.getHobby());

		//特技
		employee.setTalent(employeeUpdateRequest.getTalent());

		//自己紹介
		employee.setSelf_introduction(employeeUpdateRequest.getSelf_introduction());

		//写真
		employee.setPhoto_path(employeeUpdateRequest.getPhoto_path());

		//		//権限番号
		//		employee.setAuthority_id(employeeUpdateRequest.getAuthority_id());

		//新卒ステータス
		employee.setNew_graduate_status(employeeUpdateRequest.getNew_graduate_status());

		//雇用形態
		employee.setEmployment_status(employeeUpdateRequest.getEmployment_status());

		//在職ステータス
		employee.setTenure_status(employeeUpdateRequest.getTenure_status());

		//登録者
		employee.setInsert_person(employeeUpdateRequest.getInsert_person());

		//更新者
		employee.setUpdate_person(employeeUpdateRequest.getUpdate_person());

		//削除者
		employee.setDelete_person(employeeUpdateRequest.getDelete_person());

		//登録日時
		employee.setInsert_date(now);

		//更新日時
		employee.setUpdate_date(now);

		//削除日時
		employee.setDelete_date(now);

		//退職日時
		employee.setRetirement_date(now);

		// Employeeを保存
		employeeRepository.save(employee);

		// Assignmentの情報を設定

		//所属番号
		assignment.setAssignmentId(assignmentUpdateRequest.getAssignment_id());

		//社員ID
		assignment.setEmployeeId(employee.getEmployee_id());

		//部署番号
		assignment.setDepartmentId(assignmentUpdateRequest.getDepartment_id());

		//グループ番号
		assignment.setGroupId(assignmentUpdateRequest.getGroup_id());

		//役職番号
		assignment.setPostId(assignmentUpdateRequest.getPost_id());

		//登録者
		assignment.setInsertPerson(employeeUpdateRequest.getInsert_person());

		//更新者
		assignment.setUpdatePerson(assignmentUpdateRequest.getUpdate_person());

		//削除者
		assignment.setDeletePerson(assignmentUpdateRequest.getDelete_person());

		//登録日時
		assignment.setInsertDate(now);

		//更新日時
		assignment.setUpdateDate(now);

		//削除日時
		assignment.setDeleteDate(now);

		// Assignmentを保存
		assignmentRepository.save(assignment);
	}

	/**
	* 指定された社員IDに対応する社員情報を削除するメソッド。
	*
	* @author 中村優介
	* @param employee_id 削除する社員のID
	* 
	*/

	public void delete(Integer employee_id) {

		//findByIdメソッドで削除する情報を取得し代入する
		Employee employee = findById(employee_id);

		//リポジトリ経由で取得した情報を削除する
		employeeRepository.delete(employee);
	}

	/**
	 * 指定された社員IDに基づいて、資格の取得情報を3次元配列として取得します。
	 * 取得したデータは、資格の種類ごとに分類され、各資格の名前と取得年月が格納されます。
	 * 配列の構造は次のようになります:
	 * - 1次元目: 資格の種類（0: IPA, 1: ベンダー, 2: その他）
	 * - 2次元目: 各資格のスロット（最大5つまでの資格）
	 * - 3次元目: 資格名と取得年月（0: 資格名, 1: 取得年月）
	 *
	 * @author 岡田悠暉
	 * @param employee_id 資格情報を取得する社員のID
	 * @return 3次元配列に分類された資格情報
	 */

	public String[][][] getLicenses(Integer employee_id) {

		String stringLicenses = employeeRepository.findById(employee_id).get().getAcquiredLicense();

		/*
		 * 取得した資格データを
		 * ┌───────┬───────┬───────┐
		 * │      IPA     │    ベンダー  │    その他    │
		 * ├───┬───┼───┬───┼───┬───┤
		 * │資格名│ 年月 │資格名│ 年月 │資格名│ 年月 │ 
		 * └───┴───┴───┴───┴───┴───┘
		 * の形式に変換する。
		 */

		// 資格情報を格納する3次元配列
		String[][][] license_list = new String[3][5][2];

		while (true) {
			//文字列を分割し先頭の資格情報を取得
			int headLicense_Index = stringLicenses.indexOf(',');
			String headLicense = (headLicense_Index != -1) ? stringLicenses.substring(0, headLicense_Index)
					: stringLicenses;
			stringLicenses = (headLicense_Index != -1) ? stringLicenses.substring(headLicense_Index + 1) : "";

			//資格情報を資格名と資格取得日で分割
			int nameIndex = headLicense.indexOf("-");
			String licenseName = headLicense.substring(0, nameIndex);
			String licenseDate = headLicense.substring(nameIndex + 1);

			//資格名からどの種類の資格にカテゴライズするか検索する
			//データに不備があった場合はそのデータを飛ばして処理を進める
			License acquiredLicense = licenseRepository.SelectLicenseName(licenseName);
			if (acquiredLicense == null) {
				continue;
			}
			int kinds_num = acquiredLicense.getClassification();
			int license_num = 0;
			while (license_num < 5) {
				if (license_list[kinds_num][license_num][0] == null) {
					break;
				}
				license_num++;
			}

			//データの格納
			license_list[kinds_num][license_num][0] = licenseName;
			license_list[kinds_num][license_num][1] = licenseDate;

			//末端まで処理が終わったらループを抜ける
			if (headLicense_Index == -1) {
				break;
			}
		}
		return license_list;
	}

	/**
	 * 指定された社員IDに基づいて、その社員の経験年数を取得します。
	 *
	 * @author 岡田悠暉
	 * @param employee_id 経験年数を取得する社員のID
	 * @return 社員の経験年数
	 */

	public int getPeriodOfExperience(Integer employee_id) {
		return employeeRepository.findById(employee_id).get().getExperience_year();
	}
}