package com.example.employeeIntroduction.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.employeeIntroduction.entity.Authority;

/**
 * 権限情報に関するデータベース操作を行うリポジトリインターフェース。
 * JpaRepositoryを継承しており、標準的なCRUD操作に加えて、独自のクエリメソッドを提供します。
 * 
 * @author 中村優介
 * 
 */

@Repository
public interface AuthorityRepository extends JpaRepository<Authority, Integer> {
	

}