package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import lombok.Data;


@Data
public class DbRequest implements Serializable {

	private int db_id;	
	
	private String db_name;
	
	private String insert_person;	
	
	private String update_person;	
	
	private String delete_person;		
	
	private String insert_date;		
	
	private String update_date;		
	
	private String delete_date;		
	
				
}
