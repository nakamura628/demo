package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import lombok.Data;



@Data
public class LanguageRequest implements Serializable {

	private int language_id;
	
	private String language_name;	
	
	private String insert_person;	
	
	private String update_person;	
	
	private String delete_person;				
	
	private String insert_date;				
	
	private String update_date;			
	
	private String delete_date;			
				
}
