/**
 * EmployeeControllerクラスは、それぞれの機能の呼び出しをまとめたクラスです。
 * このクラスは、各機能に応じてServiceクラスやRepositoryクラス等にアクセスします。
 * 
 * @author　中村優介
 * @since 2024-07-17
 */

package com.example.employeeIntroduction.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.employeeIntroduction.service.EmployeeService;

@Controller
public class DeleteEmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	/**
	 *社員削除機能に関する処理
	 *
	 * @author 中村優介
	 * @param  employee_id　表示する社員ID
	 * @return 社員一覧画面のビュー名を返す。エラー発生時は社員一覧画面にリダイレクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 *
	 */

	
	@GetMapping("/deleteEmployee/{employee_id}")
	public String displayDelete(@PathVariable Integer employee_id, Model model) {

		try {

			//Serviceクラスのdeleteメソッドへ
			employeeService.delete(employee_id);

		} catch (Exception e) {

			e.printStackTrace();
			model.addAttribute("errorMsg", "正常に削除処理が行えませんでした。");
			return "redirect:/employeeList";

		}

		//社員一覧画面へ遷移
		return "redirect:/employeeList";

	}

}