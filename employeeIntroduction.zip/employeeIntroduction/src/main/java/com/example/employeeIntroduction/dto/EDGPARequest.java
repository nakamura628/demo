package com.example.employeeIntroduction.dto;

import jakarta.validation.constraints.NotNull;

import lombok.Data;

/**
 * リクエスト類をまとめたDTOクラス
 * 
 */

@Data
public class EDGPARequest {
	
    @NotNull(message = "社員番号を入力してください")
    //社員情報
    private EmployeeRequest employeeRequest;
    
    //部署情報
    private DepartmentRequest departmentRequest;
    
    //グループ情報
    private GroupRequest groupRequest;
    
    //役職情報
    private PostRequest postRequest;
    
    //所属情報
    private AssignmentRequest assignmentRequest;
   

}
