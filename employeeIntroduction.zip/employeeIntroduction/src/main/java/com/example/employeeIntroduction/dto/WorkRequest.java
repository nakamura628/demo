package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import lombok.Data;


@Data
public class WorkRequest implements Serializable {

	private int resume_id;
	
	private int work_id;					
	
	private String industry;			
	
	private String work;			
	
	private String used_language ;			
	
	private String used_db	;		
	
	private String used_os	;		
	
	private String used_server	;		
	
	private String used_framework;			
	
	private String used_ide;			
	
	private String process	;		
	
	private int team_number;			
	
	private String role;			
	
	private String period_start;			
	
	private String period_end	;		
	
	private String period_sum	;		
	
	private String detail	;			
	
	private String insert_person;				
	
	private String update_person;				
	
	private String delete_person;				
	
	private String insert_date;				
	
	private String update_date;			
	
	private String delete_date;			
				
}
