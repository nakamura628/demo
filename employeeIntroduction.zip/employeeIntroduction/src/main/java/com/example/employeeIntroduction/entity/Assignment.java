package com.example.employeeIntroduction.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * 所属情報 Entity
 * 
 */

@Getter
@Setter

@Entity
@Table(name = "assignment_info")
public class Assignment {

	/**
	 * 所属番号(主キー）
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "assignment_id")
	private int assignmentId;

	/**
	 * 社員ID（外部キー）
	 */
	@Column(name = "employee_id")
	private int employeeId;

	/**
	 * 部署番号（外部キー）
	 */
	@Column(name = "department_id")
	private int departmentId;

	/**
	 * グループ番号（外部キー）
	 */
	@Column(name = "group_id")
	private int groupId;
	
	/**
	 * 役職番号（必須）
	 */
	
	@Column(name = "post_id", nullable = false)
	private int postId;

	/**
	 * 登録者（必須、最大200文字）
	 */
	
	@Column(name = "insert_person", nullable = false, length = 200)
	private String insertPerson;

	/**
	 * 更新者（必須、最大200文字）
	 */
	
	@Column(name = "update_person", nullable = false, length = 200)
	private String updatePerson;

	/**
	 * 削除者（最大200文字）
	 */
	
	@Column(name = "delete_person", length = 200)
	private String deletePerson;

	/**
	 * 登録日（必須）
	 */
	
	@Column(name = "insert_date", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date insertDate;

	/**
	 * 更新日（必須）
	 */
	
	@Column(name = "update_date", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date updateDate;

	/**
	 * 削除日
	 */
	
	@Column(name = "delete_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date deleteDate;
	

}