package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import lombok.Data;

/**
 * グループ情報を格納するクラス
 * 
 */
@Data
public class GroupRequest implements Serializable {

	/**
	 * グループ番号
	 */
	private int group_id;
	
	/**
	 * グループ名
	 */
	private String group_name;
	
	/**
	 * 部署番号
	 */
	private int department_id;	
	
	/**
	 * 表示優先順位(1~10想定)
	 */
	private int display_priority;	
	
	/**
	 * 登録者
	 */
	private String insert_person;	
	
	/**
	 * 更新者
	 */
	private String update_person;				
	
	/**
	 * 削除者
	 */
	private String delete_person;				
	
	/**
	 * 登録日
	 */
	private String insert_date;				
	
	/**
	 * 更新日
	 */
	private String update_date;			
	
	/**
	 * 削除日
	 */
	private String delete_date;	
}
