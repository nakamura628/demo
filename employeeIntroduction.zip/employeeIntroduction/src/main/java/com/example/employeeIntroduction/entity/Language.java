package com.example.employeeIntroduction.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Entity
@Table(name="language_info")
public class Language {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "language_id")
    private int languageId;

    @Column(name = "language_name", nullable = false, length = 50, unique = true)
    private String languageName;

    @Column(name = "insert_person", nullable = false, length = 200)
    private String insertPerson;

    @Column(name = "update_person", nullable = false, length = 200)
    private String updatePerson;

    @Column(name = "delete_person", length = 200)
    private String deletePerson;

    @Column(name = "insert_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date insertDate;

    @Column(name = "update_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date updateDate;

    @Column(name = "delete_date")
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date deleteDate;
}
