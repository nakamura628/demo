/**
 * EmployeeControllerクラスは、それぞれの機能の呼び出しをまとめたクラスです。
 * このクラスは、各機能に応じてServiceクラスやRepositoryクラス等にアクセスします。
 * 
 * @author　中村優介
 * @since 2024-07-17
 */

package com.example.employeeIntroduction.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class LogoutController {

	/**
	 *ログアウト処理を行い、ログインページにリダイレクトするメソッド。
	 *
	 * @author 小松莉久
	 * @param request        HTTPリクエストオブジェクト
	 * @param response       HTTPレスポンスオブジェクト
	 * @param authentication 現在のユーザーの認証情報。nullでない場合は認証済みユーザー
	 * @param model          フロントエンドにデータを渡すためのModelオブジェクト
	 * @return ログアウト後のログインページへのリダイレクトビュー
	 *
	 */

	//ログアウト機能

	@GetMapping("/logout")
	public RedirectView logout(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication, Model model) {
		// セッションの無効化
		if (authentication != null) {
			authentication.setAuthenticated(false);
		}

		// セキュリティコンテキストとセッションの無効化
		if (authentication != null) {
			new SecurityContextLogoutHandler().logout(request, response, authentication);
			// ログアウトメッセージをコンソールに出力
			//			System.out.println("ログアウトしました");
		}

		model.addAttribute("logoutMsg", "ログアウトしました");

		// ログアウト成功後のリダイレクト先
		return new RedirectView("/login?logout=true");
	}

}