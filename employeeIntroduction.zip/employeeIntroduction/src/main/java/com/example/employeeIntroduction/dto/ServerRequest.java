package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class ServerRequest implements Serializable {

	private int server_id;			
	
	private String server_name;				
	
	private String insert_person;				
	
	private String update_person;				
	
	private String delete_person;				
	
	private String insert_date;				
	
	private String update_date;			
	
	private String delete_date;			
				
}
