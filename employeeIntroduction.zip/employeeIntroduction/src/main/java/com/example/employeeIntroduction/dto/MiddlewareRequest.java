package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import lombok.Data;


@Data
public class MiddlewareRequest implements Serializable {

	private int middleware_id;			
	
	private String middleware_name;				
	
	private String insert_person;				
	
	private String update_person;				
	
	private String delete_person;				
	
	private String insert_date;				
	
	private String update_date;			
	
	private String delete_date;			
				
}
