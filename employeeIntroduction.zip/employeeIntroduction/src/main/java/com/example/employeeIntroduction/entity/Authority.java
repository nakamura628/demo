package com.example.employeeIntroduction.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;

import lombok.Data;

/**
 * 権限情報 Entity
 * 
 */

@Entity
@Data
@Table(name ="authority_info")
public class Authority implements Serializable{
	
	/**
	 * 権限番号(主キー）
	 */
	@Id
	@Column(name="authority_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int authority_id;
	
	/**
	 * 権限名					
	 */
	@Column(name="name")
	@NotBlank
	private String name;

	/**
	 * ユーザー論理削除					
	 */
	@Column(name="user_logical_deletion_flg")
	private boolean user_logical_deletion_flg;

	/**
	 * 第三者技術経歴書閲覧					
	 */
	@Column(name="view_resume_flg")
	private boolean view_resume_flg;

	/**
	 * 第三者技術経歴書編集					
	 */
	@Column(name="update_resume_flg")
	private boolean update_resume_flg;
	
	/**
	 * 分析機能利用					
	 */
	@Column(name="analysis_flg")
	private boolean analysis_flg;

	/**
	 * 登録者（必須、最大200文字）
	 */
	@Column(name = "insert_person", nullable = false, length = 200)
    private String insert_person;

	/**
	 * 更新者（必須、最大200文字）
	 */
    @Column(name = "update_person", nullable = false, length = 200)
    private String update_person;

    /**
	 * 削除者（最大200文字）
	 */
    @Column(name = "delete_person", length = 200)
    private String delete_person;

    /**
	 * 登録日（必須）
	 */
    @Column(name = "insert_date", nullable = false)
    private LocalDateTime insert_date;

    /**
	 * 更新日（必須）
	 */
    @Column(name = "update_date", nullable = false)
    private LocalDateTime update_date;

    /**
	 * 削除日
	 */
    @Column(name = "delete_date")
    private LocalDateTime delete_date;
	
	//@OneToMany(mappedBy = "authority_id")
	//private List<Employee> employees;
	
	




}