/*
 * 作成日：07/17
 * 作成者：中野大希
 * 表示優先度順にソートされた社員リストを渡す、
 * また入力されたキーワードで絞った社員リストを渡し画面遷移するクラス
 * 
 */
package com.example.employeeIntroduction.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.employeeIntroduction.entity.Authority;
import com.example.employeeIntroduction.repository.AuthorityRepository;


@Controller
public class A011_AuthorityListController {

	
	@Autowired
	private AuthorityRepository authorityRepository;

	
	
	/**
	 * 権限リストを取得して、ビューに渡すメソッド。
	 * 
	 * @author 中野大希
	 * @param mav ModelAndViewオブジェクト。ビューとモデルのデータを保持。
	 * @return 権限一覧画面のビュー名を返す。エラー発生時は権限一覧画面にリダイレクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */
	
	
	@GetMapping("/authorityList")
	public ModelAndView AuthorityList(ModelAndView mav) {

		try {

			List<Authority> authorityList = authorityRepository.findAll();
			

			// 作成したリストを渡す
			mav.addObject("authorityList", authorityList);

		} catch (Exception e) {

//			mav.addObject("errorMsg", e);
			
			mav.addObject("errorMsg", "正常に画面表示が行えませんでした。");

			// 画面に出力するViewを指定
			mav.setViewName("A011_authorityList");

			return mav;
		}

//		mav.addObject("errorMsg", "not found error");

		// 画面に出力するViewを指定
		mav.setViewName("A011_authorityList");

		return mav;

	}
	

	/**
	 * 新規権限を追加するメソッド。
	 * 
	 * @author 中野大希
	 * @param mav ModelAndViewオブジェクト。ビューとモデルのデータを保持。
	 * @param authentication OAuth2AuthenticationTokenオブジェクト。認証情報を保持し、ユーザーのプロフィール情報にアクセスできる。
	 * @return 権限一覧画面のビュー名を返す。エラー発生時は権限一覧画面にリダイレクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */
	
	@GetMapping("/authorityListAdd")
	public ModelAndView AuthorityListAdd(ModelAndView mav,OAuth2AuthenticationToken authentication) {

		try {

			// 新規権限データを作成
			Authority authority = new Authority();
			authority.setName("新しい権限");
			authority.setUser_logical_deletion_flg(false);
			authority.setView_resume_flg(false);
			authority.setUpdate_resume_flg(false);
			authority.setAnalysis_flg(false);
			
			//登録するユーザー名を取得
			String userName = authentication.getPrincipal().getAttribute("name");
			
			authority.setInsert_person(userName);
			authority.setUpdate_person(userName);
			authority.setInsert_date(LocalDateTime.now());
			authority.setUpdate_date(LocalDateTime.now());

			// 作成した権限を追加
			authorityRepository.save(authority);

			List<Authority> authorityList = authorityRepository.findAll();

			// 作成したリストを渡す
			mav.addObject("authorityList", authorityList);

		} catch (Exception e) {

//			mav.addObject("errorMsg", e);
			
			mav.addObject("errorMsg", "正常に権限追加が行えませんでした。");

			// 画面に出力するViewを指定
			mav.setViewName("A011_authorityList");

			return mav;
		}

//		mav.addObject("errorMsg", "not found error");

		// 画面に出力するViewを指定
		mav.setViewName("A011_authorityList");

		return mav;

	}

	/**
	 * 権限を削除するメソッド。
	 * 
	 * @author 中野大希
	 * @param mav ModelAndViewオブジェクト。ビューとモデルのデータを保持。
	 * @param authority_id 削除対象の権限のID。
	 * @return 権限一覧画面のビュー名を返す。エラー発生時は権限一覧画面にリダイレクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */
	
	@GetMapping("/authorityListDelete")
	public ModelAndView AuthorityListDelete(ModelAndView mav, @RequestParam Integer authority_id) {

		try {

			// パラメータで取得した権限データを削除
			authorityRepository.deleteById(authority_id);

			List<Authority> authorityList = authorityRepository.findAll();

			// 作成したリストを渡す
			mav.addObject("authorityList", authorityList);

		} catch (Exception e) {

//			mav.addObject("errorMsg", e);
			
			mav.addObject("errorMsg", "正常に権限を削除できませんでした。");

			// 画面に出力するViewを指定
			mav.setViewName("A011_authorityList");

			return mav;
		}

//		mav.addObject("errorMsg", "not found error");

		// 画面に出力するViewを指定
		mav.setViewName("A011_authorityList");

		return mav;

	}

}
