/**
 * EmployeeControllerクラスは、それぞれの機能の呼び出しをまとめたクラスです。
 * このクラスは、各機能に応じてServiceクラスやRepositoryクラス等にアクセスします。
 * 
 * @author　中村優介
 * @since 2024-07-17
 */

package com.example.employeeIntroduction.controller;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.employeeIntroduction.entity.Assignment;
import com.example.employeeIntroduction.entity.Department;
import com.example.employeeIntroduction.entity.Employee;
import com.example.employeeIntroduction.entity.Group;
import com.example.employeeIntroduction.entity.Post;
import com.example.employeeIntroduction.repository.AssignmentRepository;
import com.example.employeeIntroduction.repository.DepartmentRepository;
import com.example.employeeIntroduction.repository.EmployeeRepository;
import com.example.employeeIntroduction.repository.GroupRepository;
import com.example.employeeIntroduction.repository.PostRepository;

@Controller
public class A002_EmployeeListController {

	@Autowired
	private EmployeeRepository employeeRepository;
	@Autowired
	private AssignmentRepository assignmentRepository;
	@Autowired
	private DepartmentRepository departmentRepository;
	@Autowired
	private GroupRepository groupRepository;
	@Autowired
	private PostRepository postRepository;

	/**
	 * 社員リストを取得して表示順にソートし、ビューに渡すメソッド。
	 * 
	 * @author 中野大希
	 * @param mav ModelAndViewオブジェクト。ビューとモデルのデータを保持。
	 * @return ソートされた社員リストとその所属情報を含むModelAndViewオブジェクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */

	@GetMapping("/employeeList")
	public ModelAndView EmployeeList(ModelAndView mav) {

		try {

			// 社員リスト全件取得
			Iterable<Employee> employeeList = employeeRepository.findAll();

			// 社員を表示順にソート==========================================================

			// 表示順指定処理
			Map<Employee, Integer> priorityMap = new HashMap<>();

			Map<Employee, String> assignmentMap = new HashMap<>();

			for (Employee employee : employeeList) {
				// 所属取得
				ArrayList<Assignment> assignmentList = (ArrayList<Assignment>) assignmentRepository
						.findByEmployeeId(employee.getEmployee_id());

				for (int i = 0; i < assignmentList.size(); i++) {

					Department department = departmentRepository
							.getReferenceById(assignmentList.get(i).getDepartmentId());

					Group group = groupRepository.getReferenceById(assignmentList.get(i).getGroupId());

					Post post = postRepository.getReferenceById(assignmentList.get(i).getPostId());

					String assignmentName = department.getDepartment_name() + "-" + group.getGroup_name() + "-"
							+ post.getPost_name();

					// 表示優先度取得
					int departmentNum = department.getDisplay_priority();

					int groupNum = group.getDisplay_priority();

					int postNum = post.getDisplay_priority();

					// 表示優先度の合計計算
					int priority = departmentNum * 100 + groupNum * 10 + postNum;

					// 複数所属社員用にデータを追加
					if (i >= 1) {
						Employee tempEmployee = new Employee();
						// 表示や画面遷移に必要な項目のみ修正
						tempEmployee.setEmployee_id(employee.getEmployee_id());

						tempEmployee.setName(employee.getName());

						tempEmployee.setPhoto_path(employee.getPhoto_path());

						employee = tempEmployee;
					}

					priorityMap.put(employee, priority);

					assignmentMap.put(employee, assignmentName);

				}
			}

			// 表示優先度でソートされた社員リスト作成
			ArrayList<Employee> sortedEmployeeList = (ArrayList<Employee>) priorityMap
					.entrySet()
					.stream()
					.sorted(Map.Entry.comparingByValue())
					.map(Map.Entry::getKey)
					.collect(Collectors.toList());

			// 表示優先度でソートされた役職リスト作成
			ArrayList<String> sortedAssignmentList = new ArrayList<String>();

			for (Employee e : sortedEmployeeList) {

				sortedAssignmentList.add(assignmentMap.get(e));
			}

			// ソートしたものを渡す

			mav.addObject("sortedEmployeeList", sortedEmployeeList);

			mav.addObject("sortedAssignmentList", sortedAssignmentList);

		} catch (Exception e) {

			//			mav.addObject("errorMsg", e);

			mav.addObject("errorMsg", "正常に画面表示が行えませんでした。");

			// 画面に出力するViewを指定
			mav.setViewName("employeeList");

			return mav;
		}

		//		mav.addObject("errorMsg", "not found error");

		// 画面に出力するViewを指定
		mav.setViewName("employeeList");

		return mav;

	}

	/**
	 * 検索キーワードに基づいて社員リストを取得し、表示順にソートしてビューに渡すメソッド。
	 * 
	 * @author 中野大希
	 * @param mav ModelAndViewオブジェクト。ビューとモデルのデータを保持。
	 * @param keyword 画面から渡された検索キーワード。複数キーワードは " - " で区切られる。
	 * @return ソートされた社員リストとその所属情報を含むModelAndViewオブジェクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */

	@GetMapping("/searchEmployeeList")
	public ModelAndView SearchEmployee(ModelAndView mav, @RequestParam String keyword) {

		try {

			//画面からのキーワードを配列として格納
			String[] keywordArray = keyword.split(" - ");

			// 社員リスト全件取得
			Iterable<Employee> employeeList = employeeRepository.findAll();

			// ソート用マップ作成
			Map<Employee, Integer> priorityMap = new HashMap<>();

			Map<Employee, String> assignmentMap = new HashMap<>();

			// 社員全メソッドを取得
			Method[] employeeMethodArray = new Employee().getClass().getDeclaredMethods();

			// キーワードに合致する社員をマップに追加
			for (Employee tempEmployee : employeeList) {

				//文字列を格納する変数
				String employeeInfo = "";

				// 全フィールド情報を取得
				for (Method tempMethod : employeeMethodArray) {

					// セッターの場合スキップ
					if (tempMethod.getName().contains("set")) {
						continue;
					}

					//社員情報の全ての情報を足していき、一つの文字列として格納する
					employeeInfo += String.valueOf(tempMethod.invoke(tempEmployee));

				}

				// 資格情報を取得

				// 所属情報を取得
				ArrayList<Assignment> assignmentList = (ArrayList<Assignment>) assignmentRepository
						.findByEmployeeId(tempEmployee.getEmployee_id());

				for (int i = 0; i < assignmentList.size(); i++) {
					Department department = departmentRepository
							.getReferenceById(assignmentList.get(i).getDepartmentId());

					Group group = groupRepository.getReferenceById(assignmentList.get(i).getGroupId());

					Post post = postRepository.getReferenceById(assignmentList.get(i).getPostId());

					String assignmentName = department.getDepartment_name() + "-" + group.getGroup_name() + "-"
							+ post.getPost_name();

					// 表示優先度取得
					int departmentNum = department.getDisplay_priority();

					int groupNum = group.getDisplay_priority();

					int postNum = post.getDisplay_priority();

					// 表示優先度の合計計算
					int priority = departmentNum * 100 + groupNum * 10 + postNum;

					// 複数所属社員用にデータを追加
					if (i >= 1) {
						Employee temp = new Employee();
						temp.setEmployee_id(tempEmployee.getEmployee_id());

						temp.setName(tempEmployee.getName());

						temp.setPhoto_path(tempEmployee.getPhoto_path());

						tempEmployee = temp;
					}

					// 全てのキーワードを満たしている場合リストに追加
					for (int j = 0; j < keywordArray.length; j++) {

						// キーワードが含まれない場合break
						if (!(employeeInfo + assignmentName).contains(keywordArray[j])) {
							break;
						}
						if (j == keywordArray.length - 1) {
							priorityMap.put(tempEmployee, priority);

							assignmentMap.put(tempEmployee, assignmentName);
						}
					}
				}
			}

			// 表示優先度でソートされた社員リスト作成
			ArrayList<Employee> sortedEmployeeList = (ArrayList<Employee>) priorityMap
					.entrySet()
					.stream()
					.sorted(Map.Entry.comparingByValue())
					.map(Map.Entry::getKey)
					.collect(Collectors.toList());

			// 表示優先度でソートされた役職リスト作成
			ArrayList<String> sortedAssignmentList = new ArrayList<String>();

			for (Employee e : sortedEmployeeList) {
				sortedAssignmentList.add(assignmentMap.get(e));
			}

			// ソートしたものを渡す
			mav.addObject("sortedEmployeeList", sortedEmployeeList);

			mav.addObject("sortedAssignmentList", sortedAssignmentList);

		} catch (Exception e) {

			//			mav.addObject("errorMsg", e);

			mav.addObject("errorMsg", "正常に検索処理が行えませんでした。");

			// 画面に出力するViewを指定
			mav.setViewName("employeeList");

			return mav;
		}

		//		mav.addObject("errorMsg", "not found error");

		// 画面に出力するViewを指定
		mav.setViewName("employeeList");

		return mav;

	}

}