/**
 * EmployeeControllerクラスは、それぞれの機能の呼び出しをまとめたクラスです。
 * このクラスは、各機能に応じてServiceクラスやRepositoryクラス等にアクセスします。
 * 
 * @author　中村優介
 * @since 2024-07-17
 */

package com.example.employeeIntroduction.controller;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.employeeIntroduction.entity.Assignment;
import com.example.employeeIntroduction.entity.Department;
import com.example.employeeIntroduction.entity.Employee;
import com.example.employeeIntroduction.entity.Group;
import com.example.employeeIntroduction.entity.Post;
import com.example.employeeIntroduction.entity.Work;
import com.example.employeeIntroduction.repository.AssignmentRepository;
import com.example.employeeIntroduction.repository.DepartmentRepository;
import com.example.employeeIntroduction.repository.EmployeeRepository;
import com.example.employeeIntroduction.repository.GroupRepository;
import com.example.employeeIntroduction.repository.LanguageRepository;
import com.example.employeeIntroduction.repository.LicenseRepository;
import com.example.employeeIntroduction.repository.MiddlewareRepository;
import com.example.employeeIntroduction.repository.PostRepository;
import com.example.employeeIntroduction.repository.ResumeRepository;
import com.example.employeeIntroduction.repository.WorkRepository;

@Controller
public class A009_SearchEmployeeController {

	@Autowired
	private EmployeeRepository employeeRepository;
	@Autowired
	private AssignmentRepository assignmentRepository;
	@Autowired
	private DepartmentRepository departmentRepository;
	@Autowired
	private GroupRepository groupRepository;
	@Autowired
	private PostRepository postRepository;
	@Autowired
	private LicenseRepository licenseRepository;
	@Autowired
	private LanguageRepository languageRepository;
	@Autowired
	private MiddlewareRepository middlewareRepository;
	@Autowired
	private WorkRepository workRepository;
	@Autowired
	private ResumeRepository resumeRepository;

	/**
	 *社員検索画面を表示する処理
	 *
	 * @author 中野大希
	 * @param mav ModelAndViewオブジェクト。ビューとモデルのデータを保持。
	 * @return 社員検索画面のビュー名を返す。エラー発生時は社員検索画面にリダイレクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */

	@GetMapping("/searchEmployee")
	public ModelAndView SearchEmployee(ModelAndView mav) {

		try {

			// 検索項目定義 ==============================================================
			// 検索できる項目マップ<value,表示名>
			Map<String, String> searchItemMap = new HashMap<>();

			//			searchItemMap.put("none", "選択してください");

			searchItemMap.put("department", "部署");

			searchItemMap.put("group", "グループ");

			searchItemMap.put("post", "役職");

			searchItemMap.put("acquiredLicense", "資格");

			searchItemMap.put("acquiredLanguage", "言語");

			searchItemMap.put("acquiredMiddleware", "ミドルウェア");

			searchItemMap.put("experienceYear", "経験年数");

			searchItemMap.put("industry", "業種");

			// 条件項目マップ
			Map<String, String> conditionItemMap = new HashMap<>();

			//			conditionItemMap.put("none", "選択してください");

			conditionItemMap.put("equal", "等しい");

			conditionItemMap.put("included", "含まれる");

			conditionItemMap.put("notIncluded", "含まない");

			conditionItemMap.put("more", "以上");

			conditionItemMap.put("less", "以下");

			// 検索値マップ
			Map<String, String> valueItemMap = new HashMap<>();

			List<String> numList = new ArrayList<>();

			for (int i = 0; i < 10; i++) {
				numList.add("" + i);
			}

			List<String> keyList = new ArrayList<>(); // マップのキー用リスト

			//			keyList.addAll(0, departmentRepository.findDepartmentName().stream().map(s -> "department" + s)
			//					.collect(Collectors.toList()));

			keyList.addAll(departmentRepository.findDepartmentName().stream().map(s -> "department" + s)
					.collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1,
					groupRepository.findGroupName().stream().distinct().map(s -> "group" + s)
							.collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1,
					postRepository.findPostName().stream().map(s -> "post" + s).collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1,
					licenseRepository.findLicenseName().stream().map(s -> "license" + s).collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1,
					languageRepository.findLanguageName().stream().map(s -> "language" + s)
							.collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1,
					middlewareRepository.findMiddlewareName().stream().map(s -> "middleware" + s)
							.collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1,
					workRepository.findDistinctIndustry().stream().map(s -> "industry" + s)
							.collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1, numList);

			ArrayList<String> valueList = new ArrayList<>(); // マップの値用リスト

			valueList.addAll(0, departmentRepository.findDepartmentName());

			valueList.addAll(valueList.size() - 1,
					groupRepository.findGroupName().stream().distinct().collect(Collectors.toList()));

			valueList.addAll(valueList.size() - 1, postRepository.findPostName());

			valueList.addAll(valueList.size() - 1, licenseRepository.findLicenseName());

			valueList.addAll(valueList.size() - 1, languageRepository.findLanguageName());

			valueList.addAll(valueList.size() - 1, middlewareRepository.findMiddlewareName());

			valueList.addAll(valueList.size() - 1, workRepository.findDistinctIndustry());

			valueList.addAll(valueList.size() - 1, numList);

			valueItemMap = IntStream.range(0, keyList.size()).boxed()
					.collect(Collectors.toMap(keyList::get, valueList::get));

			// 検索処理 ==============================================================
			// 社員リスト全件取得
			Iterable<Employee> employeeList = employeeRepository.findAll();

			// 検索結果社員リスト作成
			ArrayList<Employee> employeeArrayList = new ArrayList<Employee>();
			// 検索結果所属マップ作成
			Map<Employee, String> departmentMap = new HashMap<>();

			Map<Employee, String> groupMap = new HashMap<>();

			Map<Employee, String> workMap = new HashMap<>();

			// キーワードに合致する社員をリストに追加
			for (Employee tempEmployee : employeeList) {

				// 資格情報を取得

				// 所属情報を取得
				ArrayList<Assignment> assignmentList = (ArrayList<Assignment>) assignmentRepository
						.findByEmployeeId(tempEmployee.getEmployee_id());

				String departmentName = "";

				String groupName = "";

				for (int i = 0; i < assignmentList.size(); i++) {
					// 複数所属の場合は改行タグを挿入
					if (i >= 1) {
						departmentName += " <br> ";
						groupName += " <br> ";
					}

					Department department = departmentRepository
							.getReferenceById(assignmentList.get(i).getDepartmentId());

					Group group = groupRepository.getReferenceById(assignmentList.get(i).getGroupId());

					Post post = postRepository.getReferenceById(assignmentList.get(i).getPostId());

					departmentName += department.getDepartment_name();

					groupName += group.getGroup_name();
				}

				// 画面表示用の業種を社員IDから取得
				String industry = "";
				List<Work> workList = workRepository.findByEmployeeId(tempEmployee.getEmployee_id());
				List<String> industryList = workList.stream()
						.map(Work::getIndustry).collect(Collectors.toList());

				for (String tempIndustry : industryList) {
					industry += tempIndustry + ",";
				}
				//				// 最後のカンマを削除
				//				industry = industry.substring(0, industry.length() - 1);

				// 表示用に名称を省略
				departmentName = departmentName.replace("ビジネスソリューション", "BS");

				employeeArrayList.add(tempEmployee);

				departmentMap.put(tempEmployee, departmentName);

				groupMap.put(tempEmployee, groupName);

				workMap.put(tempEmployee, industry);
			}

			// 作成したリストを渡す
			mav.addObject("searchItemMap", searchItemMap);

			mav.addObject("conditionItemMap", conditionItemMap);

			mav.addObject("valueItemMap", valueItemMap);

			mav.addObject("employeeArrayList", employeeArrayList);

			mav.addObject("departmentMap", departmentMap);

			mav.addObject("groupMap", groupMap);

			mav.addObject("workMap", workMap);

		} catch (Exception e) {

			//			mav.addObject("errorMsg", e);

			mav.addObject("errorMsg", "正常に画面表示が行えませんでした。");

			// 画面に出力するViewを指定
			mav.setViewName("A009_searchEmployee");

			return mav;
		}

		//		mav.addObject("errorMsg", "not found error");

		// 画面に出力するViewを指定
		mav.setViewName("A009_searchEmployee");

		return mav;

	}

	/**
	 *社員検索機能（検索結果）に関する処理
	 *
	 * @author 中野大希
	 * @param mav ModelAndViewオブジェクト。ビューとモデルのデータを保持。
	 * @param keyword 画面から渡された検索キーワード。複数キーワードは " - " で区切られる。
	 * @return 社員検索画面のビュー名を返す。エラー発生時は社員検索画面にリダイレクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */

	
	@GetMapping("/searchEmployeeResult")
	public ModelAndView SearchEmployeeResult(ModelAndView mav, @RequestParam String keyword) {

		try {

			// 検索項目定義 ==============================================================
			// 検索できる項目マップ<value,表示名>
			Map<String, String> searchItemMap = new HashMap<>();

			//			searchItemMap.put("none", "選択してください");

			searchItemMap.put("department", "部署");

			searchItemMap.put("group", "グループ");

			searchItemMap.put("post", "役職");

			searchItemMap.put("acquiredLicense", "資格");

			searchItemMap.put("acquiredLanguage", "言語");

			searchItemMap.put("acquiredMiddleware", "ミドルウェア");

			searchItemMap.put("experienceYear", "経験年数");

			searchItemMap.put("industry", "業種");

			// 条件項目マップ
			Map<String, String> conditionItemMap = new HashMap<>();

			//			conditionItemMap.put("none", "選択してください");

			conditionItemMap.put("included", "含む");

			conditionItemMap.put("notIncluded", "含まない");

			conditionItemMap.put("more", "以上");

			conditionItemMap.put("less", "以下");

			// 検索値マップ
			Map<String, String> valueItemMap = new HashMap<>();
			List<String> numList = new ArrayList<>();
			for (int i = 0; i < 10; i++) {
				numList.add("" + i);
			}

			List<String> keyList = new ArrayList<>(); // マップのキー用リスト

			keyList.addAll(0, departmentRepository.findDepartmentName().stream().map(s -> "department" + s)
					.collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1,
					groupRepository.findGroupName().stream().distinct().map(s -> "group" + s)
							.collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1,
					postRepository.findPostName().stream().map(s -> "post" + s).collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1,
					licenseRepository.findLicenseName().stream().map(s -> "license" + s).collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1,
					languageRepository.findLanguageName().stream().map(s -> "language" + s)
							.collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1,
					middlewareRepository.findMiddlewareName().stream().map(s -> "middleware" + s)
							.collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1,
					workRepository.findDistinctIndustry().stream().map(s -> "industry" + s)
							.collect(Collectors.toList()));

			keyList.addAll(keyList.size() - 1, numList);

			ArrayList<String> valueList = new ArrayList<>(); // マップの値用リスト

			valueList.addAll(0, departmentRepository.findDepartmentName());
			valueList.addAll(valueList.size() - 1,
					groupRepository.findGroupName().stream().distinct().collect(Collectors.toList()));

			valueList.addAll(valueList.size() - 1, postRepository.findPostName());

			valueList.addAll(valueList.size() - 1, licenseRepository.findLicenseName());

			valueList.addAll(valueList.size() - 1, languageRepository.findLanguageName());

			valueList.addAll(valueList.size() - 1, middlewareRepository.findMiddlewareName());

			valueList.addAll(valueList.size() - 1, workRepository.findDistinctIndustry());

			valueList.addAll(valueList.size() - 1, numList);

			valueItemMap = IntStream.range(0, keyList.size()).boxed()
					.collect(Collectors.toMap(keyList::get, valueList::get));

			// 検索処理 ==============================================================
			String[] keywordArray = keyword.split(" - ");

			List<String> keywordItemList = new ArrayList<>();
			List<String> keywordConditionList = new ArrayList<>();
			List<String> keywordValueList = new ArrayList<>();

			for (int i = 0; i < keywordArray.length; i++) {
				keywordItemList.add(keywordArray[i].split(",")[0]);
				keywordConditionList.add(keywordArray[i].split(",")[1]);
				keywordValueList.add(keywordArray[i].split(",")[2]);
			}

			// 社員リスト全件取得
			Iterable<Employee> employeeList = employeeRepository.findAll();

			// 検索結果社員リスト作成
			ArrayList<Employee> employeeArrayList = new ArrayList<Employee>();

			// 検索結果所属マップ作成
			Map<Employee, String> departmentMap = new HashMap<>();

			Map<Employee, String> groupMap = new HashMap<>();

			Map<Employee, String> workMap = new HashMap<>();

			// 社員全メソッドを取得
			Method[] employeeMethodArray = new Employee().getClass().getDeclaredMethods();

			// キーワードに合致する社員をリストに追加
			outerloop: for (Employee tempEmployee : employeeList) {

				// 所属情報を取得
				List<Assignment> assignmentList = assignmentRepository.findByEmployeeId(tempEmployee.getEmployee_id());

				String assignmentName = "";

				String departmentName = "";

				String groupName = "";

				String postName = "";

				for (int i = 0; i < assignmentList.size(); i++) {
					// 複数所属の場合は改行タグを挿入
					if (i >= 1) {
						departmentName += " <br> ";
						groupName += " <br> ";
					}

					Department department = departmentRepository
							.getReferenceById(assignmentList.get(i).getDepartmentId());

					Group group = groupRepository.getReferenceById(assignmentList.get(i).getGroupId());

					Post post = postRepository.getReferenceById(assignmentList.get(i).getPostId());

					assignmentName += department.getDepartment_name() + group.getGroup_name() + post.getPost_name();

					departmentName += department.getDepartment_name();

					groupName += group.getGroup_name();

					postName += post.getPost_name();
				}

				// 画面表示用の業種を社員IDから取得
				String industry = "";
				List<Work> workList = workRepository.findByEmployeeId(tempEmployee.getEmployee_id());
				List<String> industryList = workList.stream()
						.map(Work::getIndustry).collect(Collectors.toList());

				for (String tempIndustry : industryList) {
					industry += tempIndustry + ",";
				}
				//				// 最後のカンマを削除
				//				industry = industry.substring(0, industry.length() - 1);

				//				List<Resume> resumeList = employeeService.pickupAll();
				//
				//				for (int i = 0; i < resumeList.size(); i++) {
				//					Work work = workRepository.getReferenceById(resumeList.get(i).getResumeId());
				//
				//					String workIndustry = work.getIndustry();
				//
				//					mav.addObject("workIndustry", workIndustry);
				//
				//				}

				// 条件項目対応版switch文 ========================================================
				for (int j = 0; j < keywordArray.length; j++) {

					switch (keywordItemList.get(j)) {
					case "department":

						// 条件が"含む"の場合、一致しなければ次の社員に移る
						if (keywordConditionList.get(j).equals("included")) {
							if (!departmentName.contains(keywordValueList.get(j)))
								continue outerloop;
						}

						// 条件が"含まない"の場合、一致すれば次の社員に移る
						if (keywordConditionList.get(j).equals("notIncluded")) {
							if (departmentName.contains(keywordValueList.get(j)))
								continue outerloop;
						}
						break;

					case "group":

						// 条件が"含む"の場合、一致しなければ次の社員に移る
						if (keywordConditionList.get(j).equals("included")) {
							if (!groupName.contains(keywordValueList.get(j)))
								continue outerloop;
						}

						// 条件が"含まない"の場合、一致すれば次の社員に移る
						if (keywordConditionList.get(j).equals("notIncluded")) {
							if (groupName.contains(keywordValueList.get(j)))
								continue outerloop;
						}
						break;

					case "post":

						// 条件が"含む"の場合、一致しなければ次の社員に移る
						if (keywordConditionList.get(j).equals("included")) {
							if (!postName.contains(keywordValueList.get(j)))
								continue outerloop;
						}

						// 条件が"含まない"の場合、一致すれば次の社員に移る
						if (keywordConditionList.get(j).equals("notIncluded")) {
							if (postName.contains(keywordValueList.get(j)))
								continue outerloop;
						}
						break;

					case "acquiredLanguage":
						// 習得言語を取得
						String acquiredLanguage = tempEmployee.getAcquiredLanguage();

						// 条件が"含む"の場合、一致しなければ次の社員に移る
						if (keywordConditionList.get(j).equals("included")) {
							if (!acquiredLanguage.contains(keywordValueList.get(j)))
								continue outerloop;
						}

						// 条件が"含まない"の場合、一致すれば次の社員に移る
						if (keywordConditionList.get(j).equals("notIncluded")) {
							if (acquiredLanguage.contains(keywordValueList.get(j)))
								continue outerloop;
						}
						break;

					case "acquiredMiddleware":
						// 習得言語を取得
						String acquiredMiddleware = tempEmployee.getAcquiredMiddleware();

						// 条件が"含む"の場合、一致しなければ次の社員に移る
						if (keywordConditionList.get(j).equals("included")) {
							if (!acquiredMiddleware.contains(keywordValueList.get(j)))
								continue outerloop;
						}

						// 条件が"含まない"の場合、一致すれば次の社員に移る
						if (keywordConditionList.get(j).equals("notIncluded")) {
							if (acquiredMiddleware.contains(keywordValueList.get(j)))
								continue outerloop;
						}
						break;

					case "acquiredLicense":
						// 習得資格を取得
						String acquiredLicense = tempEmployee.getAcquiredLicense();

						// 条件が"含む"の場合、一致しなければ次の社員に移る
						if (keywordConditionList.get(j).equals("included")) {
							if (!acquiredLicense.contains(keywordValueList.get(j)))
								continue outerloop;
						}

						// 条件が"含まない"の場合、一致すれば次の社員に移る
						if (keywordConditionList.get(j).equals("notIncluded")) {
							if (acquiredLicense.contains(keywordValueList.get(j)))
								continue outerloop;
						}
						break;

					case "experienceYear":
						// 経験年数を取得
						int experienceYear = tempEmployee.getExperience_year();

						// 一致しなかった場合次の社員に移る

						// 条件が"以上"の場合、経験年数が値より小さければ次の社員に移る
						if (keywordConditionList.get(j).equals("more")) {
							if (experienceYear < Integer.parseInt(keywordValueList.get(j)))
								continue outerloop;
						}

						// 条件が"以下"の場合、経験年数が値より大きければ次の社員に移る
						if (keywordConditionList.get(j).equals("less")) {
							if (experienceYear > Integer.parseInt(keywordValueList.get(j)))
								continue outerloop;
						}
						break;

					case "industry":
						// 業種リストは取得済み

						// 条件が"含む"の場合、一致しなければ次の社員に移る
						if (keywordConditionList.get(j).equals("included")) {
							if (!industryList.contains(keywordValueList.get(j)))
								continue outerloop;
						}

						// 条件が"含まない"の場合、一致すれば次の社員に移る
						if (keywordConditionList.get(j).equals("notIncluded")) {
							if (industryList.contains(keywordValueList.get(j)))
								continue outerloop;
						}
						break;

					default:
						continue outerloop;
					}
				}

				// 表示用に名称を省略
				departmentName = departmentName.replace("ビジネスソリューション", "BS");

				// 渡す情報を作成
				employeeArrayList.add(tempEmployee);

				departmentMap.put(tempEmployee, departmentName);

				groupMap.put(tempEmployee, groupName);

				workMap.put(tempEmployee, industry);

			}

			// 作成したマップを渡す
			mav.addObject("searchItemMap", searchItemMap);

			mav.addObject("conditionItemMap", conditionItemMap);

			mav.addObject("valueItemMap", valueItemMap);

			mav.addObject("employeeArrayList", employeeArrayList);

			mav.addObject("departmentMap", departmentMap);

			mav.addObject("groupMap", groupMap);

			mav.addObject("workMap", workMap);

		} catch (Exception e) {

			//			mav.addObject("errorMsg", e);

			mav.addObject("errorMsg", "正常に検索処理が行えませんでした。");

			// 画面に出力するViewを指定
			mav.setViewName("A009_searchEmployee");

			return mav;
		}

		//		mav.addObject("errorMsg", "not found error");

		// 画面に出力するViewを指定
		mav.setViewName("A009_searchEmployee");

		return mav;

	}

}