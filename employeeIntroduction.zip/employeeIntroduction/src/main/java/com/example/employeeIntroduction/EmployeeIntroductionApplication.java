package com.example.employeeIntroduction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeIntroductionApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeIntroductionApplication.class, args);
	}

}
