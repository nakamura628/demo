package com.example.employeeIntroduction.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * 所属情報を格納するクラス
 * 
 */

@Data
public class AssignmentRequest implements Serializable {

	/**
	 * 所属番号
	 */
	private int assignment_id;
	
	/**
	 * 社員ID
	 */
	private int employee_id;
	
	/**
	 * 役職番号
	 */
	private int post_id;
	
	/**
	 * 部署番号
	 */
	private int department_id;
	
	/**
	 * グループ番号
	 */
	private int group_id;
	
	/**
	 * 登録者
	 */
	private String insert_person;				
	
	/**
	 * 更新者
	 */
	private String update_person;				
	
	/**
	 * 削除者
	 */
	private String delete_person;				
	
	/**
	 * 登録日
	 */
	private Date insert_date;				
	
	/**
	 * 更新日
	 */
	private Date update_date;			
	
	/**
	 * 削除日
	 */
	private Date delete_date;
}
