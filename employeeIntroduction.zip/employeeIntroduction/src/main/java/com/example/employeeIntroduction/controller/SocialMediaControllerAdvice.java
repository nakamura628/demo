/**
 * SocialMediaControllerAdviceクラスは、全てのコントローラーで共通して使用される
 * ソーシャルメディアのURLをモデルに追加するためのアドバイスクラスです。
 *
 * このクラスは、リクエストごとに実行され、SNSリンクをビューで利用できるようにします。
 * 
 * @author 小松莉久
 * @since 2024-07-26
 */
package com.example.employeeIntroduction.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.example.employeeIntroduction.entity.Authority;
import com.example.employeeIntroduction.entity.Employee;
import com.example.employeeIntroduction.repository.AuthorityRepository;
import com.example.employeeIntroduction.repository.EmployeeRepository;

@ControllerAdvice
public class SocialMediaControllerAdvice {

	@Autowired
	private EmployeeRepository employeeRepository;
	@Autowired
	private AuthorityRepository authorityRepository;

	/**
	 * ソーシャルメディアのURLをモデルに追加します。
	 * 
	 * このメソッドは、すべてのリクエストで実行され、
	 * 指定されたSNSリンクをモデルに追加します。
	 * 
	 * @author 小松莉久
	 * @param model モデルオブジェクト。属性が追加されます。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */

	
	@ModelAttribute
	public void addAttributes(Model model) {
		try {

			model.addAttribute("twitterUrl", "https://twitter.com/DreamJackGames");
			model.addAttribute("instagramUrl", "https://www.instagram.com/dreamjack_official/");
			model.addAttribute("facebookUrl", "https://www.facebook.com/enjoydreamjack/");
			model.addAttribute("youtubeUrl", "https://www.youtube.com/@user-tq3hq1tm4e");
			model.addAttribute("tiktokUrl", "https://www.tiktok.com/@dreamjack_officia");
			model.addAttribute("homeJack", "https://home-jack.fun/");
			model.addAttribute("djHP", "https://www.dream-jack.com/");

		} catch (Exception e) {
			//mav.addObject("errorMsg", e);

			//パラメーターで画面にエラー情報を渡す
			model.addAttribute("errorMsg", "正常にフッター情報を取得できませんでした。");

		}
	}

	/**
	 *ユーザーの認証情報に基づいて、ヘッダーに表示する情報を返すメソッド。
	 *
	 * @author 中村優介
	 * @param model Modelオブジェクト。取得したユーザー情報を画面に渡すために使用。
	 * @param authentication OAuth2AuthenticationTokenオブジェクト。認証情報を使用してログイン中のユーザーのIDと名前を取得。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */

	@ModelAttribute
	public void addHeaderToModel(Model model, OAuth2AuthenticationToken authentication) {

		try {
			//DJのGoogleアカウントがある場合
			if (authentication != null && authentication.getPrincipal() != null) {

				//ユーザー名とアイコン画像を取得
				String userName = authentication.getPrincipal().getAttribute("name");

				String picture = authentication.getPrincipal().getAttribute("picture"); // プロフィール画像の取得

				// 社員リスト全件取得
				List<Employee> employeeList = employeeRepository.findAll();

				for (Employee employee : employeeList) {

					//authority_idを引数として、リポジトリ経由で権限情報を取得
					Authority authority = authorityRepository.getReferenceById(employee.getAuthority_id());

					//ユーザー名と社員情報の氏名が一致する場合は社員IDを取得
					if (employee.getName().contains(userName)) {

						int userId = employee.getEmployee_id();

						//パラメーターで画面に取得情報を渡す
						model.addAttribute("userId", userId);
					}

					//パラメーターで画面に取得情報を渡す
					model.addAttribute("authority", authority);
				}

				//パラメーターで画面に取得情報を渡す
				model.addAttribute("username", userName);

				model.addAttribute("picture", picture);

				//DJのGoogleアカウントがない場合
			} else {

				//パラメーターで画面に取得情報を渡す（ゲスト扱い）
				model.addAttribute("username", "Guest");
			}
		} catch (Exception e) {
			//mav.addObject("errorMsg", e);

			//パラメーターで画面にエラー情報を渡す
			model.addAttribute("errorMsg", "正常にヘッダー情報を取得できませんでした。");
		}
	}

}
