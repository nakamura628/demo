package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class FrameworkRequest implements Serializable {

	private int framework_id;	
	
	private String framework_name;
	
	private String insert_person;	
	
	private String update_person;				
	
	private String delete_person;				
	
	private String insert_date;				
	
	private String update_date;			
	
	private String delete_date;			
				
}
