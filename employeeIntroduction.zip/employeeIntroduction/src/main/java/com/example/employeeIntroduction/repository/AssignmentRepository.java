package com.example.employeeIntroduction.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.employeeIntroduction.entity.Assignment;

/**
 * 配属情報に関するデータベース操作を行うリポジトリインターフェース。
 * JpaRepositoryを継承しており、標準的なCRUD操作に加えて、独自のクエリメソッドを提供します。
 * 
 * @author 中野大希、中村優介
 * 
 */

@Repository
public interface AssignmentRepository extends JpaRepository<Assignment,Integer>{
	
	/**
     * 指定された社員のIDに関連するAssignmentのリストを取得します。
     *
     * @author 中野大希、中村優介
     * @param employee_id 社員のID
     * @return 関連するAssignmentのリスト
     * 
     */
	
	public List<Assignment> findByEmployeeId(int employee_id);

	
	}