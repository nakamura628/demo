package com.example.employeeIntroduction.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.employeeIntroduction.dto.WorkRequest;
import com.example.employeeIntroduction.entity.Work;
import com.example.employeeIntroduction.repository.WorkRepository;


@Service
@Transactional(rollbackFor = Exception.class)
public class WorkService {

	@Autowired
	private WorkRepository workRepository;
	
	/**
	 * 指定された履歴書IDに基づいて、Workエンティティのリストを取得します。
	 *
	 * @author 岡田悠暉
	 * @param resume_id 履歴書のID
	 * @return 指定された履歴書IDに関連するWorkのリスト
	 */
	
	public  List<Work> findByResumeId(Integer resume_id) {
		 return workRepository.SelectByResumeID(resume_id);
	}

	public void insert(WorkRequest[] workRequests) {
		
	}

	public void update(Integer work_id,WorkRequest workRequest) {
		
	}
	
	public void delete(Integer work_id) {
		
	}
}