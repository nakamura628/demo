/**
 * EmployeeControllerクラスは、それぞれの機能の呼び出しをまとめたクラスです。
 * このクラスは、各機能に応じてServiceクラスやRepositoryクラス等にアクセスします。
 * 
 * @author　中村優介
 * @since 2024-07-17
 */

package com.example.employeeIntroduction.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.employeeIntroduction.dto.AssignmentUpdateRequest;
import com.example.employeeIntroduction.dto.EDGPAUpdateRequest;
import com.example.employeeIntroduction.dto.EmployeeUpdateRequest;
import com.example.employeeIntroduction.entity.Assignment;
import com.example.employeeIntroduction.entity.Department;
import com.example.employeeIntroduction.entity.Employee;
import com.example.employeeIntroduction.entity.Group;
import com.example.employeeIntroduction.entity.Post;
import com.example.employeeIntroduction.repository.AssignmentRepository;
import com.example.employeeIntroduction.service.EmployeeService;
import com.example.employeeIntroduction.service.FileStorageService;

@Controller
public class A005_UpdateEmployeeDetailController {

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private AssignmentRepository assignmentRepository;

	@Autowired
	private FileStorageService fileStorageService;

	/**
	 *社員更新画面を表示する処理
	 *
	 * @author 中村優介
	 * @param  employee_id　表示する社員ID
	 * @param  model   {@link Model} オブジェクトで、ビューに渡すモデルデータを管理します。
	 * @return 社員更新画面	 
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 *
	 */

	@GetMapping("/updateEmployeeDetail/{employee_id}")
	public String displayUpdate(@PathVariable Integer employee_id, Model model) {

		try {

			//登録している情報を取得して、フォームに反映する
			Employee employee = employeeService.findById(employee_id);

			//employee_idを引数として、リポジトリ経由で所属情報を取得
			ArrayList<Assignment> assignmentList = (ArrayList<Assignment>) assignmentRepository
					.findByEmployeeId(employee_id);

			//登録情報を格納するオブジェクトを生成
			EDGPAUpdateRequest request = new EDGPAUpdateRequest();

			request.setEmployeeUpdateRequest(new EmployeeUpdateRequest());

			request.setAssignmentUpdateRequest(new AssignmentUpdateRequest());

			// 各リクエストオブジェクトを取得
			EmployeeUpdateRequest employeeUpdateRequest = request.getEmployeeUpdateRequest();

			AssignmentUpdateRequest assignmentUpdateRequest = request.getAssignmentUpdateRequest();

			Date now = new Date();

			//登録されている各情報を格納
			employeeUpdateRequest.setEmployee_id(employee.getEmployee_id());

			//社員番号
			employeeUpdateRequest.setEmployee_number(employee.getEmployee_number());

			//氏名
			employeeUpdateRequest.setName(employee.getName());

			//氏名（かな）
			employeeUpdateRequest.setName_ruby(employee.getName_ruby());

			//氏名（ローマ字）
			employeeUpdateRequest.setName_alphabet(employee.getName_alphabet());

			//開発経験年数
			employeeUpdateRequest.setExperience_year(employee.getExperience_year());

			//社内メールアドレス
			employeeUpdateRequest.setE_mail(employee.getE_mail());

			//電話番号
			employeeUpdateRequest.setPhone_number(employee.getPhone_number());

			//生年月日
			employeeUpdateRequest.setBirth_date(employee.getBirth_date());

			//入社年月
			employeeUpdateRequest.setEntry_date(employee.getEntry_date());

			//資格
			employeeUpdateRequest.setAcquired_license(employee.getAcquiredLicense());

			//習得言語
			employeeUpdateRequest.setAcquired_language(employee.getAcquiredLanguage());

			//習得ミドルウェア
			employeeUpdateRequest.setAcquired_middleware(employee.getAcquiredMiddleware());

			//趣味
			employeeUpdateRequest.setHobby(employee.getHobby());

			//特技
			employeeUpdateRequest.setTalent(employee.getTalent());

			//自己紹介
			employeeUpdateRequest.setSelf_introduction(employee.getSelf_introduction());

			//写真
			employeeUpdateRequest.setPhoto_path(employee.getPhoto_path());

			//新卒ステータス
			employeeUpdateRequest.setNew_graduate_status(employee.getNew_graduate_status());

			//雇用形態
			employeeUpdateRequest.setEmployment_status(employee.getEmployment_status());

			//在職ステータス
			employeeUpdateRequest.setTenure_status(employee.getTenure_status());

			//登録者
			employeeUpdateRequest.setInsert_person(employee.getInsert_person());

			//更新者
			employeeUpdateRequest.setUpdate_person(employee.getUpdate_person());

			//削除者
			employeeUpdateRequest.setDelete_person(employee.getDelete_person());

			//登録日時
			employeeUpdateRequest.setInsert_date(employee.getInsert_date());

			//更新日時
			employeeUpdateRequest.setUpdate_date(now);

			//削除日時
			employeeUpdateRequest.setDelete_date(now);

			//所属情報を用いて、部署、グループ、役職の必要な情報を取得する
			for (int i = 0; i < assignmentList.size(); i++) {

				//部署番号
				assignmentUpdateRequest.setDepartment_id(assignmentList.get(i).getDepartmentId());

				//グループ番号
				assignmentUpdateRequest.setGroup_id(assignmentList.get(i).getGroupId());

				//役職番号
				assignmentUpdateRequest.setPost_id(assignmentList.get(i).getPostId());

				//社員ID
				assignmentUpdateRequest.setEmployee_id(employee.getEmployee_id());

				//登録者
				assignmentUpdateRequest.setInsert_person(assignmentList.get(i).getInsertPerson());

				//更新者
				assignmentUpdateRequest.setUpdate_person(assignmentList.get(i).getUpdatePerson());

				//削除者
				assignmentUpdateRequest.setDelete_person(assignmentList.get(i).getDeletePerson());

				//登録日時
				assignmentUpdateRequest.setInsert_date(assignmentList.get(i).getInsertDate());

				//更新日時
				assignmentUpdateRequest.setUpdate_date(now);

				//削除日時
				assignmentUpdateRequest.setDelete_date(now);

			}

			//パラメーターで画面に登録情報を渡す
			model.addAttribute("EDGPAUpdateRequest", request);

			//部署、グループ、役職の情報を取得
			Iterable<Department> departmentList = employeeService.catchAll();
			model.addAttribute("DepartmentMap", departmentList);

			Iterable<Group> GroupList = employeeService.findAll();
			model.addAttribute("GroupMap", GroupList);

			Iterable<Post> PostList = employeeService.getAll();
			model.addAttribute("PostMap", PostList);

		} catch (Exception e) {

			//mav.addObject("errorMsg", e);

			//パラメーターで画面にエラー情報を渡す
			model.addAttribute("errorMsg", "正常に画面表示が行えませんでした。");

			//エラーが発生したら社員一覧へ戻る
			return "redirect:/employeeList";
		}

		//社員更新画面へ遷移
		return "/A005_updateEmployeeDetail";

	}

	/**
	 *社員更新機能に関する処理
	 *
	 * @author 中村優介
	 * @param  employeeUpdateRequest リクエストデータ
	 * @param request {@link EDGPAUpdateRequest} オブジェクトで、社員の更新する情報および割り当て情報を含む。
	 * @param file アップロードされた写真ファイル。{@link MultipartFile} オブジェクトとして受け取ります。
	 * @param result {@link BindingResult} オブジェクトで、バリデーションエラーの情報を保持します。
	 * @param model {@link Model} オブジェクトで、ビューに渡すモデルデータを管理します。
	 * @param authentication {@link OAuth2AuthenticationToken} オブジェクトで、認証されたユーザーの情報を提供します。
	 * @throws IllegalArgumentException {@code request} が {@code null} の場合にスローされます。
	 * @throws IOException ファイルの保存中にエラーが発生した場合にスローされます。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * @return 社員一覧画面
	 *
	 */

	@PostMapping("/updateEmployeeDetail")
	public String update(@ModelAttribute("EDGPAUpdateRequest") @Valid EDGPAUpdateRequest request, BindingResult result,
			@RequestParam("photo") MultipartFile file,
			Model model,
			OAuth2AuthenticationToken authentication) {

		//リクエストの中が空の場合
		if (request == null) {
			throw new IllegalArgumentException("Request cannot be null");
		}

		// 各リクエストオブジェクトを取得
		EmployeeUpdateRequest employeeUpdateRequest = request.getEmployeeUpdateRequest();
		AssignmentUpdateRequest assignmentUpdateRequest = request.getAssignmentUpdateRequest();

		// バリデーションエラーをチェック
		if (result.hasErrors()) {

			result.getAllErrors().forEach(error -> {
				System.out.println("Error: " + error.getDefaultMessage());
			});

			return "A005_updateEmployeeDetail"; // フォームビューに戻る
		}

		// ログインしているユーザー名取得
		if (authentication != null && authentication.getPrincipal() != null) {
			String userName = authentication.getPrincipal().getAttribute("name");

			// 登録者を設定
			employeeUpdateRequest.setInsert_person(userName);
			assignmentUpdateRequest.setInsert_person(userName);

			// 更新者を設定
			employeeUpdateRequest.setUpdate_person(userName);
			assignmentUpdateRequest.setUpdate_person(userName);

		}

		// ファイルの処理
		try {
			// ファイルの保存処理をServiceに委譲
			String imageUrl = fileStorageService.storeFile(file);

			model.addAttribute("imageUrl", imageUrl);

			//ファイルURLを格納する
			employeeUpdateRequest.setPhoto_path(imageUrl);

		} catch (IOException e) {
			e.printStackTrace();
			model.addAttribute("errorMsg", "ファイルの保存中にエラーが発生しました。");
			return "A005_updateEmployeeDetail"; // フォームビューに戻る
		}

		try {

			// サービスクラスのメソッドupdateを呼び出す
			employeeService.update(employeeUpdateRequest, assignmentUpdateRequest);

		} catch (Exception e) {

			e.printStackTrace();
			model.addAttribute("errorMsg", "正常に更新処理が行えませんでした。");
			return "A005_updateEmployeeDetail"; // フォームビューに戻る

		}

		//社員一覧画面へ遷移
		return "redirect:/employeeList";

	}

}