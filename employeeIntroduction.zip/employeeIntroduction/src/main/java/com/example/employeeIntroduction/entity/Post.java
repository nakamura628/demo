package com.example.employeeIntroduction.entity;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;

import lombok.Data;

/**
 * 役職情報 Entity
 */

@Entity
@Data
@Table(name ="post_info")
public class Post implements Serializable{
	
	/**
	 * 役職番号
	 */
	@Id
	@Column(name="post_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int post_id;
	
	/**
	 * 役職名
	 */
	@Column(name="post_name")
	private String post_name;
	
	/**
	 * 表示優先順位(1~10想定)
	 */
	@Column(name="display_priority")
	private int display_priority;	
	
	/**
	 * 登録者
	 */
	@Column(name="insert_person",length = 200)
	@CreatedBy
	private String insert_person;	
	
	/**
	 * 更新者
	 */
	@Column(name="update_person",length = 200)
	@LastModifiedBy
	private String update_person;
	
	/**
	 * 削除者
	 */
	@Column(name="delete_person",length = 200)
	private String delete_person;	
	
	/**
	 * 登録日
	 */
	@Column(name="insert_date")
	@Temporal(TemporalType.TIMESTAMP)
	private  Date insert_date;
	
	/**
	 * 更新日
	 */
	@Column(name="update_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date update_date;
	
	/**
	 * 削除日
	 */
	@Column(name="delete_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date delete_date;	
	
	
//	@OneToMany(mappedBy = "post")
//    private Set<Assignment> assignments;
}



