package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import lombok.Data;


@Data
public class ResumeRequest implements Serializable {

		
	private int resume_id;
	
	
	private int employee_id;
	
	private String initial;	
	
	private int age;	
	
	private String gender;	
	
	private String station;	
	
	private String self_pr;	
	
	private String insert_person;				
	
	private String update_person;				
	
	private String delete_person;				
	
	private String insert_date;				
	
	private String update_date;			
	
	private String delete_date;
			
}
