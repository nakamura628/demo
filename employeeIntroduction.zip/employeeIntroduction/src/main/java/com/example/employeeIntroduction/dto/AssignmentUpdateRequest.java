package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import jakarta.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 画面から更新する配属情報を格納するクラス
 * AssignmentRequestを継承しているクラス
 * 
 */

@Data
@EqualsAndHashCode(callSuper=false)
public class AssignmentUpdateRequest extends  AssignmentRequest implements Serializable{
	
	@NotNull
	private int assignment_id;

}
