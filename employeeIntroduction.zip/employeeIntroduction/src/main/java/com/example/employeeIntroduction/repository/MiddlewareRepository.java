package com.example.employeeIntroduction.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.employeeIntroduction.entity.Middleware;

/**
 * ミドルウェア情報に関するデータベース操作を行うリポジトリインターフェース。
 * JpaRepositoryを継承しており、標準的なCRUD操作に加えて、独自のクエリメソッドを提供します。
 * 
 * @author 中野大希
 * 
 */

public interface MiddlewareRepository extends JpaRepository<Middleware,Integer>{

	/**
	 * 全ミドルウェアの名前を取得するメソッド。
	 * データベース内のすべてのミドルウェア名をリストで返します。
	 *
	 * @author 中野大希
	 * @return ミドルウェア名のリスト
	 * 
	 */
	
	@Query("select m.middlewareName FROM Middleware m ")
	List<String> findMiddlewareName();
}
