package com.example.employeeIntroduction.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.employeeIntroduction.entity.Resume;
import com.example.employeeIntroduction.entity.Work;
import com.example.employeeIntroduction.repository.ResumeRepository;

@Service
@Transactional(rollbackFor = Exception.class)
public class ResumeService {

	@Autowired
	private ResumeRepository resumeRepository;
	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private WorkService workService;

	/**
	 * 社員IDに基づき、履歴書情報を取得する。
	 * 
	 * @author 岡田悠暉
	 * @param employeeId 取得する社員のID
	 * @return 指定された社員IDの履歴情報
	 */
	
	public Resume findById(Integer employeeId) {
		return resumeRepository.findById(employeeId).get();
	}

	/**
	 * 履歴書情報を保存または更新する。
	 * 
	 * @author 岡田悠暉
	 * @param resume 保存または更新する履歴書情報
	 */
	
	public void saveResume(Resume resume) {
		resumeRepository.save(resume);
	}

	/**
	 * 指定された社員IDに基づいて、履歴書のデータをExcelテンプレートに挿入し、Excelファイルを生成する。
	 * 
	 * @author 岡田悠暉
	 * @param employeeId 履歴書データを挿入する社員のID
	 * @return Excelファイルデータのバイト配列
	 */
	
	public byte[] populateTemplateWithData(Integer employeeId) {
		try (InputStream is = new ClassPathResource("ResumeTemplate/ResumeTemplate.xlsx").getInputStream();
				Workbook workbook = new XSSFWorkbook(is)) {

			Sheet sheet = workbook.getSheetAt(0); // 最初のシートを取得

			// 社員番号をB6セルに設定
			Row row = sheet.getRow(5); // 6行目（インデックスは0ベース）
			if (row == null) {
				row = sheet.createRow(5);
			}
			Cell cell = row.getCell(1); // B列
			if (cell == null) {
				cell = row.createCell(1);
			}
			cell.setCellValue(employeeService.findById(employeeId).getEmployee_number()); // 社員番号を設定

			// 社員名をD6セルに設定
			cell = row.getCell(3); // D列
			if (cell == null) {
				cell = row.createCell(3);
			}
			cell.setCellValue(employeeService.findById(employeeId).getName());

			// イニシャルをH6セルに設定
			cell = row.getCell(7); // H列
			if (cell == null) {
				cell = row.createCell(7);
			}
			cell.setCellValue(resumeRepository.findById(employeeId).get().getInitial());

			// IPA資格をI6セルに設定
			cell = row.getCell(8); // I列
			if (cell == null) {
				cell = row.createCell(8);
			}
			cell.setCellValue(Extractionlicenses(employeeId, 0, 0)); // IPA資格を設定

			// 取得年月 (IPA) をK6セルに設定
			cell = row.getCell(10); // K列
			if (cell == null) {
				cell = row.createCell(10);
			}
			cell.setCellValue(Extractionlicenses(employeeId, 0, 1));

			// ベンダー資格をL6セルに設定
			cell = row.getCell(11); // L列
			if (cell == null) {
				cell = row.createCell(11);
			}
			cell.setCellValue(Extractionlicenses(employeeId, 1, 0)); // ベンダー資格を設定

			// 取得年月 (ベンダー資格) をN6セルに設定
			cell = row.getCell(13); // N列
			if (cell == null) {
				cell = row.createCell(13);
			}
			cell.setCellValue(Extractionlicenses(employeeId, 1, 1));

			// その他資格をO6セルに設定
			cell = row.getCell(14); // O列
			if (cell == null) {
				cell = row.createCell(14);
			}
			cell.setCellValue(Extractionlicenses(employeeId, 2, 0)); // その他資格を設定

			// 取得年月 (その他資格) をQ6セルに設定
			cell = row.getCell(16); // Q列
			if (cell == null) {
				cell = row.createCell(16);
			}
			cell.setCellValue(Extractionlicenses(employeeId, 2, 1));

			// 経験年数をR6セルに設定
			cell = row.getCell(17); // R列
			if (cell == null) {
				cell = row.createCell(17);
			}
			cell.setCellValue(employeeService.getPeriodOfExperience(employeeId)); // 経験年数を設定

			// 年齢をB8セルに設定
			row = sheet.getRow(7); // 8行目（インデックスは0ベース）
			if (row == null) {
				row = sheet.createRow(7);
			}
			cell = row.getCell(1); // B列
			if (cell == null) {
				cell = row.createCell(1);
			}
			cell.setCellValue(resumeRepository.findById(employeeId).get().getAge());

			// 性別をD8セルに設定
			cell = row.getCell(3); // D列
			if (cell == null) {
				cell = row.createCell(3);
			}
			cell.setCellValue(resumeRepository.findById(employeeId).get().getGender());

			// 最寄駅をE8セルに設定
			cell = row.getCell(4); // E列
			if (cell == null) {
				cell = row.createCell(4);
			}
			cell.setCellValue(resumeRepository.findById(employeeId).get().getStation());

			// 自己PRをB62セルに設定
			row = sheet.getRow(61); // 62行目（インデックスは0ベース）
			cell = row.getCell(1); // B列
			if (cell == null) {
				cell = row.createCell(1);
			}
			cell.setCellValue(resumeRepository.findById(employeeId).get().getSelfPr()); // 自己PRを設定

			// ---- 業務経験情報の書き込み ----
			List<Work> works = workService.findByResumeId(employeeId); // 業務情報を取得
			int startingRow = 10; // 業務経験の開始行

			for (Work work : works) {
				// 言語のリストを作成
				List<String> languageList = new ArrayList<>(Arrays.asList(""));
				if (work.getUsedLanguage() != null) {
					languageList = Arrays.asList(work.getUsedLanguage().split(","));
				}

				// データベースのリストを作成
				List<String> dbList = new ArrayList<>(Arrays.asList(""));
				if (work.getUsedDb() != null) {
					dbList = Arrays.asList(work.getUsedDb().split(","));
				}

				// OSのリストを作成
				List<String> osList = new ArrayList<>(Arrays.asList(""));
				if (work.getUsedOs() != null) {
					osList = Arrays.asList(work.getUsedOs().split(","));
				}

				// サーバのリストを作成
				List<String> serverList = new ArrayList<>(Arrays.asList(""));
				if (work.getUsedServer() != null) {
					serverList = Arrays.asList(work.getUsedServer().split(","));
				}

				// フレームワークのリストを作成
				List<String> frameworkList = new ArrayList<>(Arrays.asList(""));
				if (work.getUsedFramework() != null) {
					frameworkList = Arrays.asList(work.getUsedFramework().split(","));
				}

				// 統合開発環境（IDE）のリストを作成
				List<String> IDEList = new ArrayList<>(Arrays.asList(""));
				if (work.getUsedIde() != null) {
					IDEList = Arrays.asList(work.getUsedIde().split(","));
				}

				// 行を取得、なければ作成
				Row workRow = sheet.getRow(startingRow);
				if (workRow == null) {
					workRow = sheet.createRow(startingRow);
				}

				// 業種をC列に設定
				Cell workCell = workRow.getCell(2); // C列
				workCell.setCellValue(work.getIndustry() == null ? "" : work.getIndustry());

				// 業務をD列に設定
				workCell = workRow.getCell(3); // D列
				workCell.setCellValue(work.getWork() == null ? "" : work.getWork());

				// 言語リストをF列に設定
				int indexRownum = startingRow;
				Row indexRow = sheet.getRow(startingRow);
				for (String language : languageList) {
					indexRow = sheet.getRow(indexRownum);
					if (indexRow == null) {
						indexRow = sheet.createRow(indexRownum); // 必要に応じて行を作成
					}
					workCell = indexRow.getCell(5); // F列
					if (workCell == null) {
						workCell = indexRow.createCell(5);
					}
					workCell.setCellValue(language); // 言語を設定
					indexRownum++;
				}

				// データベースリストをG列に設定
				indexRownum = startingRow;
				for (String db : dbList) {
					indexRow = sheet.getRow(indexRownum);
					if (indexRow == null) {
						indexRow = sheet.createRow(indexRownum); // 必要に応じて行を作成
					}
					workCell = indexRow.getCell(6); // G列
					if (workCell == null) {
						workCell = indexRow.createCell(6);
					}
					workCell.setCellValue(db); // データベースを設定
					indexRownum++;
				}

				// OSリストをH列に設定
				indexRownum = startingRow;
				for (String os : osList) {
					indexRow = sheet.getRow(indexRownum);
					if (indexRow == null) {
						indexRow = sheet.createRow(indexRownum); // 必要に応じて行を作成
					}
					workCell = indexRow.getCell(7); // H列
					if (workCell == null) {
						workCell = indexRow.createCell(7);
					}
					workCell.setCellValue(os); // OSを設定
					indexRownum++;
				}

				// サーバリストをI列に設定
				indexRownum = startingRow;
				for (String server : serverList) {
					indexRow = sheet.getRow(indexRownum);
					if (indexRow == null) {
						indexRow = sheet.createRow(indexRownum); // 必要に応じて行を作成
					}
					workCell = indexRow.getCell(8); // I列
					if (workCell == null) {
						workCell = indexRow.createCell(8);
					}
					workCell.setCellValue(server); // サーバを設定
					indexRownum++;
				}

				// フレームワークリストをJ列に設定
				indexRownum = startingRow;
				for (String framework : frameworkList) {
					indexRow = sheet.getRow(indexRownum);
					if (indexRow == null) {
						indexRow = sheet.createRow(indexRownum); // 必要に応じて行を作成
					}
					workCell = indexRow.getCell(9); // J列
					if (workCell == null) {
						workCell = indexRow.createCell(9);
					}
					workCell.setCellValue(framework); // フレームワークを設定
					indexRownum++;
				}

				// 統合開発環境リストをK列に設定
				indexRownum = startingRow;
				for (String ide : IDEList) {
					indexRow = sheet.getRow(indexRownum);
					if (indexRow == null) {
						indexRow = sheet.createRow(indexRownum); // 必要に応じて行を作成
					}
					workCell = indexRow.getCell(10); // K列
					if (workCell == null) {
						workCell = indexRow.createCell(10);
					}
					workCell.setCellValue(ide); // 統合開発環境を設定
					indexRownum++;
				}

				// 工程をL列に設定
				List<String> processList = Arrays.asList(work.getProcess().split("-"));
				workCell = workRow.getCell(11); // L列
				if (workCell == null) {
					workCell = workRow.createCell(11);
				}
				workCell.setCellValue(processList.get(0)); // 工程1を設定
				indexRow = sheet.getRow(startingRow + 3);
				workCell = indexRow.getCell(11);
				if (workCell == null) {
					workCell = workRow.createCell(11);
				}
				workCell.setCellValue(processList.get(1)); // 工程2を設定

				// チーム人数をM列に設定
				workCell = workRow.getCell(13); // M列
				if (workCell == null) {
					workCell = workRow.createCell(13);
				}
				workCell.setCellValue(work.getTeamNumber() == 0 ? 0 : work.getTeamNumber()); // チーム人数を設定

				// 役割をN列に設定
				workCell = workRow.getCell(14); // N列
				if (workCell == null) {
					workCell = workRow.createCell(14);
				}
				workCell.setCellValue(work.getRole() == null ? "" : work.getRole()); // 役割を設定

				// 期間をO列に設定
				workCell = workRow.getCell(15); // O列
				if (workCell == null) {
					workCell = workRow.createCell(15);
				}
				workCell.setCellValue(work.getPeriodStart() == null ? "" : work.getPeriodStart());
				indexRow = sheet.getRow(startingRow + 3);
				workCell = indexRow.getCell(15);
				if (workCell == null) {
					workCell = workRow.createCell(15);
				}
				workCell.setCellValue(work.getPeriodEnd() == null ? "" : work.getPeriodEnd());

				// 詳細をC列に設定（次の行の位置を調整）
				indexRow = sheet.getRow(startingRow + 6);
				workCell = indexRow.getCell(2);
				if (workCell == null) {
					workCell = workRow.createCell(2);
				}
				workCell.setCellValue(work.getDetail()); // 詳細を設定

				// 次の業務経験に移動
				startingRow = startingRow + 7;
			}

			// 出力用のByteArrayOutputStreamを作成
			try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
				workbook.write(outputStream);
				return outputStream.toByteArray(); // Excelデータをバイト配列として返す
			}

		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 資格情報を取得し、文字列として返す。
	 * 
	 * @author 岡田悠暉
	 * @param employeeId 資格情報を取得する社員のID
	 * @param num1 資格種別を指定するための番号
	 * @param num2 取得年月や資格名を指定するための番号
	 * @return 指定された資格情報の文字列
	 */
	
	public String Extractionlicenses(int employeeId, int num1, int num2) {

		StringBuilder result = new StringBuilder();

		// 資格情報を取得
		String[][][] licenses = employeeService.getLicenses(employeeId);

		// 取得した資格情報を文字列として結合
		for (int n = 0; n < licenses[num1].length; n++) {
			if (licenses[num1][n][num2] != null) {
				result.append(licenses[num1][n][num2]);
			}
		}

		return result.toString(); // 結合された資格情報を返す
	}
}
