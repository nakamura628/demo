package com.example.employeeIntroduction.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.employeeIntroduction.entity.Work;

/**
 * 業務情報に関するデータベース操作を行うリポジトリインターフェース。
 * JpaRepositoryを継承しており、標準的なCRUD操作に加えて、独自のクエリメソッドを提供します。
 * 
 * @author 中野大希
 * 
 */

@Repository
public interface WorkRepository extends JpaRepository<Work, Integer> {

//	@Query("select w.industry FROM Work w ")
//	List<String> findIndustry();
//	
//	List<Work> findByResumeId(int resumeId);
	
	/**
     * 指定された履歴書のIDに基づいて、関連する業種のリストを取得するメソッド。
     *
     * @author 中野大希
     * @param resumeId 履歴書のID
     * @return 業種のリスト
     */
	
	@Query("select w.industry from Work w where w.resume.resumeId = :resumeId")
	List<String> findIndustryByResumeId(@Param("resumeId") Integer resumeId);
	
	 /**
     * 業種が指定されたパターンに一致するWorkのリストを取得する。
     *
     * @author 中野大希
     * @param industry 一致させる業種のパターン
     * @return 一致するWorkのリスト
     */
	
	List<Work> findByIndustryLike(String industry);
	
	/**
     * 指定された社員IDに関連するWorkのリストを取得するメソッド。
     *
     * @author 中野大希
     * @param employee_id 社員のID
     * @return 関連するWorkのリスト
     */
	
	@Query("SELECT w FROM Work w WHERE w.resume.employee.employee_id = :employee_id")
    List<Work> findByEmployeeId(@Param("employee_id") Integer employee_id);
	
	/**
     * 指定された履歴書のIDに関連するWorkのリストを取得するメソッド。
     *
     * @author 中野大希
     * @param resumeId 履歴書のID
     * @return 関連するWorkのリスト
     */
	
	@Query("SELECT w FROM Work w WHERE w.resume.resumeId = :resumeId")
    List<Work> findByResumeId(@Param("resumeId") Integer resumeId);

	
	/**
     * データベース内の重複のない業種のリストを取得するメソッド。
     *
     * @author 中野大希
     * @return 重複のない業種のリスト
     */
	
	@Query("select distinct w.industry FROM Work w ")
	List<String> findDistinctIndustry();
	
	@Query(value = "SELECT * FROM work_info WHERE resume_id = :id ",nativeQuery = true)
    List<Work> SelectByResumeID(@Param("id") Integer id);
}