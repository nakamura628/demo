package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import lombok.Data;

/**
 * 部署情報を格納するクラス
 * 
 */

@Data
public class DepartmentRequest implements Serializable {

	/**
	 * 部署番号
	 */
	private int department_id;
	
	/**
	 * 部署名
	 */
	private String department_name;
	
	/**
	 * 表示優先順位(1~10想定)
	 */
	private int display_priority;
	
	/**
	 * 非表示フラグ(0,表示1,非表示)
	 */
	private boolean hide_flg;					
	
	/**
	 * 物理削除フラグ(0,削除しない1,削除)
	 */
	private boolean delete_flg;					
	
	/**
	 * 登録者
	 */
	private String insert_person;				
	
	/**
	 * 更新者
	 */
	private String update_person;				
	
	/**
	 * 削除者
	 */
	private String delete_person;				
	
	/**
	 * 登録日
	 */
	private String insert_date;				
	
	/**
	 * 更新日
	 */
	private String update_date;			
	
	/**
	 * 削除日
	 */
	private String delete_date;	
}
