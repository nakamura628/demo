package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class AuthorityRequest implements Serializable {

	private int authority_id;

	private String name;

	private boolean user_logical_deletion_flg;

	private boolean view_resume_flg;

	private boolean update_resume_flg;
	
	private boolean analysis_flg;
	
}
