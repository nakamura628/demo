package com.example.employeeIntroduction.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.employeeIntroduction.entity.Resume;

/**
 * 履歴書情報に関するデータベース操作を行うリポジトリインターフェース。
 * JpaRepositoryを継承しており、標準的なCRUD操作に加えて、独自のクエリメソッドを提供します。
 * 
 * @author 中野大希
 * 
 */


@Repository
public interface ResumeRepository extends JpaRepository<Resume, Integer> {
	
	/**
     * 全ての履歴書のIDを取得するメソッド。
     *
     * @author 中野大希
     * @return 履歴書のIDのリスト
     * 
     */
	
	@Query("select r.resumeId from Resume r ")
	List<Integer> findResumeId();
	
	
	/**
     * 指定された社員のIDに基づいて、関連する履歴書情報を取得するメソッド。
     *
     * @author 中野大希
     * @param employee_id 社員のID
     * @return 指定された従業員に関連する履歴書情報
     * 
     */
	
	@Query("SELECT r FROM Resume r JOIN r.employee e WHERE e.employee_id = :employee_id")
	Resume findByEmployeeEmployee_id(@Param("employee_id") int employee_id);
	
//	List<Resume> findByEmployeeId(int employee_id);

}