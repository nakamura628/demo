package com.example.employeeIntroduction.dto;

import jakarta.validation.constraints.NotNull;

import lombok.Data;

@Data
public class EmployeeDetailRequest {

	@NotNull
	private int employee_id;
	private int assignment_id;

}
