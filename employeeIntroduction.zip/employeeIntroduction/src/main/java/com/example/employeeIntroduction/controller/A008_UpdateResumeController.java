package com.example.employeeIntroduction.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.employeeIntroduction.entity.Resume;
import com.example.employeeIntroduction.service.EmployeeService;
import com.example.employeeIntroduction.service.ResumeService;

@Controller
public class A008_UpdateResumeController {

	@Autowired
	private ResumeService resumeService;
	@Autowired
	private EmployeeService employeeService;

	/**
	 * 指定された社員IDに基づいて、履歴書編集画面を表示します。
	 * 社員情報と既存の履歴書情報をモデルに追加して、編集ビューに渡します。
	 *
	 *	@author 岡田悠暉
	 * @param model ビューにデータを渡すためのModelオブジェクト
	 * @param employeeId 編集する社員のID（パス変数）
	 * @return 履歴書編集画面のビュー名 ("A008_updateResume")
	 */

	@GetMapping(value = "/resumeEdit/{employeeId}")
	public String showResumeEdit(Model model, @PathVariable Integer employeeId) {
		Resume resume = resumeService.findById(employeeId);
		// 社員情報
		model.addAttribute("EmployeeNumber", employeeService.findById(employeeId).getEmployee_number());
		model.addAttribute("EmployeeName", employeeService.findById(employeeId).getName());

		model.addAttribute("resumeForm", resume);

		return "A008_updateResume"; // 編集用のビューを表示
	}

	/**
	 * 編集された履歴書情報を保存し、保存後に履歴書プレビュー画面へリダイレクトします。
	 *
	 * @author 岡田悠暉
	 * @param resumeForm フォームから送信された履歴書データ
	 * @return 履歴書プレビュー画面へのリダイレクトURL
	 */

	@PostMapping(value = "/resumeEditSave")
	public String saveResumeEdit(@ModelAttribute("resumeForm") Resume resumeForm) {
		resumeService.saveResume(resumeForm); // 履歴書情報を保存
		return "redirect:/resumePreview?employeeId=" + resumeForm.getEmployee(); // 保存後にプレビュー画面にリダイレクト
	}
}
