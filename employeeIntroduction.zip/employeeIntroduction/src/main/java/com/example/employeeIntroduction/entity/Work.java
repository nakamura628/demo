package com.example.employeeIntroduction.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Entity
@Table(name = "work_info")
public class Work {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "work_id")
    private int workId;

    @ManyToOne
    @JoinColumn(name = "resume_id", nullable = false)
    private Resume resume;


    @Column(name = "industry", length = 50)
    private String industry;

    @Column(name = "work", length = 50)
    private String work;

    @Column(name = "used_language", length = 100)
    private String usedLanguage;

    @Column(name = "used_db", length = 100)
    private String usedDb;

    @Column(name = "used_os", length = 100)
    private String usedOs;

    @Column(name = "used_server", length = 100)
    private String usedServer;

    @Column(name = "used_framework", length = 100)
    private String usedFramework;

    @Column(name = "used_ide", length = 100)
    private String usedIde;

    @Column(name = "process", length = 100)
    private String process;

    @Column(name = "team_number")
    private int teamNumber;

    @Column(name = "role", length = 50)
    private String role;

    @Column(name = "period_start", length = 20)
    private String periodStart;

    @Column(name = "period_end", length = 20)
    private String periodEnd;

    @Column(name = "period_sum", length = 20)
    private String periodSum;

    @Column(name = "detail", columnDefinition = "TEXT")
    private String detail;

    @Column(name = "insert_person", nullable = false, length = 200)
    private String insertPerson;

    @Column(name = "update_person", nullable = false, length = 200)
    private String updatePerson;

    @Column(name = "delete_person", length = 200)
    private String deletePerson;

    @Column(name = "insert_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date insertDate;

    @Column(name = "update_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date updateDate;

    @Column(name = "delete_date")
    @Temporal(TemporalType.TIMESTAMP)
    private java.util.Date deleteDate;
}
