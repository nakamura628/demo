/*
 * 作成日：07/17
 * 作成者：中野大希
 * 表示優先度順にソートされた社員リストを渡す、
 * また入力されたキーワードで絞った社員リストを渡し画面遷移するクラス
 * 
 */
package com.example.employeeIntroduction.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.employeeIntroduction.entity.Authority;
import com.example.employeeIntroduction.entity.Employee;
import com.example.employeeIntroduction.repository.AuthorityRepository;
import com.example.employeeIntroduction.repository.EmployeeRepository;

@Controller
public class A012_AuthorityDetailController {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private AuthorityRepository authorityRepository;

	/**
	 * 指定された権限の詳細情報を表示するためのメソッド。
	 * 
	 * @author 中野大希
	 * @param mav ModelAndViewオブジェクト。ビューとモデルのデータを保持。
	 * @param authority_id 表示対象の権限のID。
	 * @return 権限詳細画面のビュー名を返す。エラー発生時は権限詳細画面にリダイレクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */

	@GetMapping("/authorityDetail")
	public ModelAndView AuthorityDetail(ModelAndView mav, @RequestParam Integer authority_id) {

		try {

			Authority authority = authorityRepository.findById(authority_id).get();

			// 社員リストを取得
			List<Employee> employeeList = employeeRepository.findAll();

			// 作成したリストを渡す
			mav.addObject("authority", authority);
			mav.addObject("authority_id", authority_id);
			mav.addObject("employeeList", employeeList);

		} catch (Exception e) {

			//			mav.addObject("errorMsg", e);

			mav.addObject("errorMsg", "正常に画面表示が行えませんでした。");

			// 画面に出力するViewを指定
			mav.setViewName("A012_authorityDetail");

			return mav;
		}

		//		mav.addObject("errorMsg", "not found error");

		// 画面に出力するViewを指定
		mav.setViewName("A012_authorityDetail");

		return mav;

	}

	/**
	 * 指定された権限の詳細情報を変更するためのメソッド。
	 * 
	 * @author 中野大希
	 * @param mav ModelAndViewオブジェクト。ビューとモデルのデータを保持。
	 * @param authority_id 変更対象の権限のID。
	 * @param name 変更対象の権限の名前。
	 * @param user_logical_deletion_flg 変更対象の権限のユーザー論理削除フラグ。
	 * @param view_resume_flg 変更対象の第三者技術経歴書閲覧フラグ。
	 * @param update_resume_flg 変更対象の第三者技術経歴書編集フラグ。
	 * @param analysis_flg 変更対象の分析機能利用フラグ。
	 * @param authentication OAuth2AuthenticationTokenオブジェクト。認証情報を保持し、ユーザーのプロフィール情報にアクセスできる。
	 * @return 権限詳細画面のビュー名を返す。エラー発生時は権限詳細画面にリダイレクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */
	
	@PostMapping("/authorityDetailUpdate")
	public ModelAndView AuthorityDetailUpdate(ModelAndView mav,
			@RequestParam("authority_id") Integer authority_id,
			@RequestParam("name") String name,
			@RequestParam("user_logical_deletion_flg") boolean user_logical_deletion_flg,
			@RequestParam("view_resume_flg") boolean view_resume_flg,
			@RequestParam("update_resume_flg") boolean update_resume_flg,
			@RequestParam("analysis_flg") boolean analysis_flg, OAuth2AuthenticationToken authentication) {

		try {

			// 取得したパラメータから権限情報を変更
			Authority authority = authorityRepository.findById(authority_id).get();
			authority.setName(name);
			authority.setUser_logical_deletion_flg(user_logical_deletion_flg);
			authority.setView_resume_flg(view_resume_flg);
			authority.setUpdate_resume_flg(update_resume_flg);
			authority.setAnalysis_flg(analysis_flg);

			//更新するユーザー名を取得
			String userName = authentication.getPrincipal().getAttribute("name");

			authority.setUpdate_person(userName);
			authority.setUpdate_date(LocalDateTime.now());

			authorityRepository.save(authority);

			// 社員リストを取得
			List<Employee> employeeList = employeeRepository.findAll();

			// 作成したリストを渡す
			mav.addObject("authority", authority);
			mav.addObject("authority_id", authority_id);
			mav.addObject("employeeList", employeeList);

		} catch (Exception e) {

			//			mav.addObject("errorMsg", e);

			mav.addObject("errorMsg", "正常に権限情報を変更できませんでした。");

			// 画面に出力するViewを指定
			mav.setViewName("A012_authorityDetail");

			return mav;
		}

		//		mav.addObject("errorMsg", "not found error");

		// 画面に出力するViewを指定
		mav.setViewName("A012_authorityDetail");

		return mav;

	}

	/**
	 * 指定された権限を適用する社員を変更するためのメソッド。
	 * 
	 * @author 中野大希
	 * @param mav ModelAndViewオブジェクト。ビューとモデルのデータを保持。
	 * @param authority_id 変更対象の権限のID。
	 * @param selectedEmployeeId 変更対象の社員のIDのリスト。
	 * @return 権限詳細画面のビュー名を返す。エラー発生時は権限詳細画面にリダイレクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */

	@PostMapping("/authorityDetailUpdateEmployee")
	public ModelAndView updateEmployeeAuthorities(ModelAndView mav,
			@RequestParam(required = false) Integer authority_id,
			@RequestParam(required = false) List<Integer> selectedEmployeeId) {

		//適用する社員を変更せずに送信した場合
		if (authority_id == null || selectedEmployeeId == null) {

			mav.addObject("errorMsg", "権限の適用が変更できていません。");

			// 画面に出力するViewを指定
			mav.setViewName("authorityDetail");

			return mav;
		}

		try {

			Authority authority = authorityRepository.findById(authority_id).get();

			// パラメータで取得した社員の権限情報を変更する
			for (int tempEmployeeId : selectedEmployeeId) {
				Employee tempEmployee = employeeRepository.findById(tempEmployeeId).get();
				tempEmployee.setAuthority_id(authority_id);

				employeeRepository.save(tempEmployee);
			}

			// 社員リストを取得
			List<Employee> employeeList = employeeRepository.findAll();

			// 作成したリストを渡す
			mav.addObject("authority", authority);
			mav.addObject("authority_id", authority_id);
			mav.addObject("employeeList", employeeList);

		} catch (Exception e) {
			//
			//			mav.addObject("errorMsg", e);

			mav.addObject("errorMsg", "正常に権限情報を変更できませんでした。");

			// 画面に出力するViewを指定
			mav.setViewName("A012_authorityDetail");

			return mav;
		}

		//		mav.addObject("errorMsg", "not found error");

		// 画面に出力するViewを指定
		mav.setViewName("A012_authorityDetail");

		return mav;

	}
}
