package com.example.employeeIntroduction.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.employeeIntroduction.entity.Employee;

/**
 * 社員情報に関するデータベース操作を行うリポジトリインターフェース。
 * JpaRepositoryを継承しており、標準的なCRUD操作に加え、独自のクエリメソッドを提供します。
 * 
 * @author 中野大希、中村優介
 * 
 */

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	/**
	 * 指定された言語キーワードに基づいて、該当する社員の数をカウントするメソッド。
	 * 社員情報の「取得した言語」または履歴書情報の「使用言語」が該当する社員を検索します。
	 *
	 * @author 中野大希
	 * @param language 検索対象の言語キーワード
	 * @return 言語キーワードに一致する社員の数
	 * 
	 */

	@Query(value = "SELECT COUNT(DISTINCT e.employee_id) FROM employee_info e " +
			"INNER JOIN resume_info r ON e.employee_id = r.employee_id " +
			"INNER JOIN work_info w ON r.resume_id = w.resume_id " +
			"WHERE e.acquired_language LIKE %:language% OR w.used_language LIKE %:language%", nativeQuery = true)
	Integer countEmployeesByLanguageKeyword(@Param("language") String language);

	// 引数の資格が経験資格に含まれる社員数を取得
	Integer countByacquiredLicenseContaining(String keyword);

	// 引数の言語が経験言語に含まれる社員数を取得
	Integer countByAcquiredLanguageContaining(String keyword);

	// 引数のミドルウェアが経験ミドルウェアに含まれる社員数を取得
	Integer countByacquiredMiddlewareContaining(String keyword);

	/**
	 * 指定された業界に該当する社員のリストを取得するメソッド。
	 * 履歴書情報に基づいて、業界キーワードに一致する社員を検索します。
	 *
	 * @author 中野大希
	 * @param industry 検索対象の業種キーワード
	 * @return 業種キーワードに一致する社員のリスト
	 * 
	 */

	@Query(value = "SELECT DISTINCT e.* FROM employee_info e " +
			"INNER JOIN resume_info r ON e.employee_id = r.employee_id " +
			"INNER JOIN work_info w ON r.resume_id = w.resume_id " +
			"WHERE w.industry LIKE %:industry%", nativeQuery = true)
	List<Employee> findEmployeesByIndustryLike(@Param("industry") String industry);
	
	@Query(value = "SELECT COUNT(DISTINCT e.employee_id) FROM employee_info e " +
			"INNER JOIN resume_info r ON e.employee_id = r.employee_id " +
			"INNER JOIN work_info w ON r.resume_id = w.resume_id " +
			"WHERE w.industry LIKE %:industry%", 
			nativeQuery = true)
	Integer countEmployeesByIndustryLike(@Param("industry") String industry);

	List<Employee> findByNameLike(String name);

	/**
	* 指定された言語キーワードに基づいて、取得した言語が一致する社員のリストを取得する。
	*
	* @author 中野大希
	* @param language 検索対象の言語キーワード
	* @return 言語キーワードに一致する社員のリスト
	* 
	*/

	List<Employee> findByAcquiredLanguageLike(String language);

	/**
	 * 指定されたミドルウェアキーワードに基づいて、取得したミドルウェアが一致する社員のリストを取得する。
	 *
	 * @author 中野大希
	 * @param middleware 検索対象のミドルウェアキーワード
	 * @return ミドルウェアキーワードに一致する社員のリスト
	 * 
	 */

	List<Employee> findByAcquiredMiddlewareLike(String middleware);

	/**
	 * 指定された資格キーワードに基づいて、取得した資格が一致する社員のリストを取得する。
	 *
	 * @author 中野大希
	 * @param license 検索対象の資格キーワード
	 * @return 資格キーワードに一致する社員のリスト
	 * 
	 */

	List<Employee> findByAcquiredLicenseLike(String license);

	/**
	 * 全社員の名前をリストで取得するメソッド。
	 *
	 * @author 中野大希
	 * @return 社員の名前のリスト
	 * 
	 */

	@Query("SELECT e.name FROM Employee e")
	List<String> findAllNames();

}