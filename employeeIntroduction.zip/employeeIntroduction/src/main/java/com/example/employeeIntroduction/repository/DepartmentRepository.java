package com.example.employeeIntroduction.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.employeeIntroduction.entity.Department;

/**
 * DB(部署情報テーブル）にアクセスするクラス
 */

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Integer> {
	
	@Query("select d.department_name FROM Department d ")
	List<String> findDepartmentName();
}