package com.example.employeeIntroduction.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.employeeIntroduction.service.ResumeService;

@Controller
public class DownloadResumeController {

	@Autowired
	private ResumeService resumeService;

	/**
	 * 指定された社員IDに基づき、履歴書データをExcelファイルとしてダウンロードします。
	 * ファイルは "resume.xlsx" という名前でダウンロードされます。
	 *
	 * @author 岡田悠暉
	 * @param employee_id 履歴書をダウンロードする対象の社員ID（パス変数）
	 * @return Excelファイルデータを含むResponseEntityオブジェクト
	 */

	@GetMapping(value = "/resumeDownload/{employee_id}")
	public ResponseEntity<byte[]> ResumeDownload(@PathVariable Integer employee_id) {

		byte[] excelData = resumeService.populateTemplateWithData(employee_id);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		headers.setContentDispositionFormData("attachment", "resume.xlsx");

		return new ResponseEntity<>(excelData, headers, HttpStatus.OK);
	}

}
