package com.example.employeeIntroduction.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Entity
@Table(name = "resume_info")
public class Resume {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "resume_id")
    private int resumeId;

    @OneToOne
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;  // 外部キーの参照として Employee エンティティを使用する場合

    @Column(name = "initial", nullable = false, length = 10)
    private String initial;

    @Column(name = "age", nullable = false)
    private int age;

    @Column(name = "gender", nullable = false, length = 10)
    private String gender;

    @Column(name = "station", nullable = false, length = 100)
    private String station;

    @Column(name = "self_pr", columnDefinition = "TEXT")
    private String selfPr;

    @Column(name = "insert_person", nullable = false, length = 200)
    private String insertPerson;

    @Column(name = "update_person", nullable = false, length = 200)
    private String updatePerson;

    @Column(name = "delete_person", length = 200)
    private String deletePerson;

    @Column(name = "insert_date", nullable = false)
    private  LocalDateTime insertDate;

    @Column(name = "update_date", nullable = false)
    private  LocalDateTime updateDate;

    @Column(name = "delete_date")
    private  LocalDateTime deleteDate;
}
