package com.example.employeeIntroduction.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.employeeIntroduction.entity.License;

/**
 * 資格情報に関するデータベース操作を行うリポジトリインターフェース。
 * JpaRepositoryを継承しており、標準的なCRUD操作に加えて、独自のクエリメソッドを提供します。
 * 
 * @author 中野大希
 * 
 */

public interface LicenseRepository extends JpaRepository<License, Integer> {

	/**
	 * 全資格の名前を取得するメソッド。
	 * データベース内のすべての資格名をリストで返します。
	 *
	 * @author 中野大希
	 * @return 資格名のリスト
	 * 
	 */

	@Query("select l.licenseName FROM License l ")
	List<String> findLicenseName();
	
	@Query(value = "SELECT * FROM license_info WHERE license_name = :name ",nativeQuery = true)
	License SelectLicenseName(@Param("name") String name);
}