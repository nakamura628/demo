package com.example.employeeIntroduction;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Spring Securityの設定を行うためのクラスです。
 * このクラスは、認証やアクセス制御に関する設定を行い、OAuth2ログイン、ログアウト、
 * ならびにURLごとのアクセス権限を管理します。
 */

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	/**
	 * セキュリティフィルタチェーンを設定します。
	 * 認証と許可に関するルール、OAuth2ログイン、ログアウトの設定を定義しています。
	 *
	 * @author 小松莉久
	 * @param http セキュリティに関するHTTP設定を提供するHttpSecurityオブジェクト。
	 * @return 設定済みのSecurityFilterChainオブジェクト。
	 * @throws Exception 設定中に発生した例外。
	 * 
	 */

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http
				.authorizeHttpRequests(authorizeRequests -> authorizeRequests
						.requestMatchers("/login", "/oauth2/**", "/logout").permitAll()
						.anyRequest().authenticated())
				.oauth2Login(oauth2Login -> oauth2Login
						.loginPage("/login")
						.defaultSuccessUrl("/home", true)
						.failureUrl("/login?error=true"))
				.logout(logout -> logout
						.logoutUrl("/logout")
						.permitAll() // アクセス制御を許可
				);
		return http.build();
	}
}
