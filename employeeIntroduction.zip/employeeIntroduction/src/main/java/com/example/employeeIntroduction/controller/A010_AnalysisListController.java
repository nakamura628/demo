/**
 * EmployeeControllerクラスは、それぞれの機能の呼び出しをまとめたクラスです。
 * このクラスは、各機能に応じてServiceクラスやRepositoryクラス等にアクセスします。
 * 
 * @author　中村優介
 * @since 2024-07-17
 */

package com.example.employeeIntroduction.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.employeeIntroduction.entity.Assignment;
import com.example.employeeIntroduction.entity.Department;
import com.example.employeeIntroduction.entity.Employee;
import com.example.employeeIntroduction.entity.Group;
import com.example.employeeIntroduction.entity.Resume;
import com.example.employeeIntroduction.entity.Work;
import com.example.employeeIntroduction.repository.AssignmentRepository;
import com.example.employeeIntroduction.repository.DepartmentRepository;
import com.example.employeeIntroduction.repository.EmployeeRepository;
import com.example.employeeIntroduction.repository.GroupRepository;
import com.example.employeeIntroduction.repository.LanguageRepository;
import com.example.employeeIntroduction.repository.LicenseRepository;
import com.example.employeeIntroduction.repository.MiddlewareRepository;
import com.example.employeeIntroduction.repository.ResumeRepository;
import com.example.employeeIntroduction.repository.WorkRepository;

@Controller
public class A010_AnalysisListController {

	@Autowired
	private EmployeeRepository employeeRepository;
	@Autowired
	private AssignmentRepository assignmentRepository;
	@Autowired
	private DepartmentRepository departmentRepository;
	@Autowired
	private GroupRepository groupRepository;
	@Autowired
	private LicenseRepository licenseRepository;
	@Autowired
	private LanguageRepository languageRepository;
	@Autowired
	private MiddlewareRepository middlewareRepository;
	@Autowired
	private WorkRepository workRepository;
	@Autowired
	private ResumeRepository resumeRepository;

	// 分析項目に一致する社員リスト
	List<Employee> employeeList = new ArrayList<>();

	// 言語項目の分析結果Map<部署-グループ名,経験年数リスト>
	Map<String, List<Integer>> analysisResultsMap = new HashMap<>();

	// 分析項目が占める割合
	String percentage = "";

	// 社員リスト表示用の社員情報Map<社員,部署-グループ>
	Map<Employee, String> employeeDisplayInfoMap = new HashMap<>();

	// 条件に一致する社員の年齢リスト
	List<Integer> ageList = new ArrayList<>();

	/**
	 * 社員分析画面を表示する処理
	 *
	 * @author 中野大希
	 * @param mav ModelAndViewオブジェクト。ビューとモデルのデータを保持。
	 * @return 社員分析画面のビュー名を返す。エラー発生時は社員分析画面にリダイレクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */

	@GetMapping("/analysisList")
	public ModelAndView analysisList(ModelAndView mav) {

		try {

			// 検索項目のリストを作成する
			List<String> languageNameList = languageRepository.findLanguageName();

			List<String> industryNameList = new ArrayList<>();

			List<Integer> resumeIdList = resumeRepository.findResumeId();

			for (int i = 0; i < resumeIdList.size(); i++) {

				if (industryNameList.size() == 0) {

					List<Work> workList = workRepository.findByResumeId(resumeIdList.get(i));

					List<String> tempIndustryNameList = workList.stream().map(Work::getIndustry)
							.collect(Collectors.toList());

					industryNameList.addAll(0, tempIndustryNameList);

					continue;
				}

				industryNameList.addAll(industryNameList.size() - 1,
						workRepository.findIndustryByResumeId(resumeIdList.get(i)));

			}

			List<String> licenseNameList = licenseRepository.findLicenseName();

			List<String> middlewareNameList = middlewareRepository.findMiddlewareName();

			List<String> processNameList = new ArrayList<>();

			processNameList.add("要件定義");

			processNameList.add("詳細設計");

			processNameList.add("概要設計");

			processNameList.add("プログラム");

			processNameList.add("単体テスト");

			processNameList.add("結合テスト");

			processNameList.add("システムテスト");

			// 作成したリストを渡す
			mav.addObject("languageNameList", languageNameList);

			mav.addObject("industryNameList", industryNameList);

			mav.addObject("licenseNameList", licenseNameList);

			mav.addObject("middlewareNameList", middlewareNameList);

			mav.addObject("processNameList", processNameList);

		} catch (Exception e) {

			//			mav.addObject("errorMsg", e);

			mav.addObject("errorMsg", "正常に画面表示が行えませんでした。");

			// 画面に出力するViewを指定
			mav.setViewName("A010_analysisList");

			return mav;
		}

		//		mav.addObject("errorMsg", "not found error");

		// 画面に出力するViewを指定
		mav.setViewName("A010_analysisList");

		return mav;

	}

	/**
	 *社員分析機能（検索結果）に関する処理
	 *
	 * @author 中野大希
	 * @param mav ModelAndViewオブジェクト。ビューとモデルのデータを保持。
	 * @param analysisItem 画面から渡された分析項目。
	 * @return 社員分析画面のビュー名を返す。エラー発生時は社員分析画面にリダイレクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */

	@GetMapping("/analysisListResult")
	public ModelAndView analysisListResult(ModelAndView mav, @RequestParam String analysisItem) {

		try {

			// 分析項目に一致する社員リスト
			employeeList = new ArrayList<>();

			// 言語項目の分析結果Map<部署-グループ名,経験年数リスト>
			analysisResultsMap = new HashMap<>();

			for (Group tempGroup : groupRepository.findAll()) {

				// 部署-グループ名の部分を記入
				String departmentName = departmentRepository.findById(tempGroup.getDepartment().getDepartment_id())
						.get()
						.getDepartment_name();

				// 表示用に名称を省略
				departmentName = departmentName.replace("ビジネスソリューション", "BS");

				String groupName = tempGroup.getGroup_name().replace("グループ", "G");

				analysisResultsMap.put(departmentName + "-" + groupName, new ArrayList<>());
			}

			// 分析項目が占める割合
			percentage = "";

			// 表示用の社員情報Map<社員,部署-グループ>
			employeeDisplayInfoMap = new HashMap<>();

			ageList = new ArrayList<>();

			// 取得した分析項目を分解
			String analysisItemName = analysisItem.split("=")[0];

			String analysisItemValue = analysisItem.split("=")[1];

			// 分析項目選択用のリストを作成する
			List<String> languageNameList = languageRepository.findLanguageName();

			List<String> middlewareNameList = middlewareRepository.findMiddlewareName();

			List<String> industryNameList = new ArrayList<>();

			{
				List<Integer> resumeIdList = resumeRepository.findResumeId();

				// 全経歴書から全業務テーブルの業種項目をリストで取得
				for (int i = 0; i < resumeIdList.size(); i++) {

					if (industryNameList.size() == 0) {

						industryNameList.addAll(0, workRepository.findIndustryByResumeId(resumeIdList.get(i)));

						continue;
					}

					industryNameList.addAll(industryNameList.size() - 1,
							workRepository.findIndustryByResumeId(resumeIdList.get(i)));

				}
				// 業種被りを除外
				Set<String> set = new HashSet<>(industryNameList);

				industryNameList = new ArrayList<>(set);
			}

			List<String> licenseNameList = licenseRepository.findLicenseName();

			List<String> processNameList = new ArrayList<>();

			processNameList.add("要件定義");

			processNameList.add("詳細設計");

			processNameList.add("概要設計");

			processNameList.add("プログラム");

			processNameList.add("単体テスト");

			processNameList.add("結合テスト");

			processNameList.add("システムテスト");

			//switch文（項目選択）
			switch (analysisItemName) {

			// 言語項目選択時 ===================================================
			case "language":

				// 指定言語が言語カラムに含まれる社員データを取得
				employeeList = employeeRepository.findByAcquiredLanguageLike("%" + analysisItemValue + "%");

				for (int i = 0; i < employeeList.size(); i++) {

					// 習得言語の配列取得
					String[] acquiredLanguageArray = employeeList.get(i).getAcquiredLanguage().split(",");

					// 分析項目に一致する言語の経験年数取得
					int experienceYear = -1;

					for (int j = 0; j < acquiredLanguageArray.length; j++) {

						if (acquiredLanguageArray[j].matches(analysisItemValue + ".*")) {

							experienceYear = Integer.parseInt(acquiredLanguageArray[j].split("-")[1]);
						}
					}

					// グラフの副カテゴリに経験年数を追加
					addGraphSubcategory(i, experienceYear);

					// 条件に一致する社員の年齢リストを追加
					Resume resume = resumeRepository.findByEmployeeEmployee_id(employeeList.get(i).getEmployee_id());

					if (resume != null) {

						ageList.add(resume.getAge());
					}
				}

				// 割合表示用処理
				percentage = "" + (int) (employeeList.size() / (float) employeeRepository.count() * 100) + "%";

				break;

			// ミドルウェア項目選択時 ===================================================
			case "middleware":

				// 指定言語が言語カラムに含まれる社員データを取得
				employeeList = employeeRepository.findByAcquiredMiddlewareLike("%" + analysisItemValue + "%");

				for (int i = 0; i < employeeList.size(); i++) {

					// 習得ミドルウェアの配列取得
					String[] acquiredMiddlewareArray = employeeList.get(i).getAcquiredMiddleware().split(",");

					// 分析項目に一致するミドルウェアの経験年数取得
					int experienceYear = -1;

					for (int j = 0; j < acquiredMiddlewareArray.length; j++) {

						if (acquiredMiddlewareArray[j].matches(analysisItemValue + ".*")) {

							experienceYear = Integer.parseInt(acquiredMiddlewareArray[j].split("-")[1]);
						}
					}

					// グラフの副カテゴリに経験年数を追加
					addGraphSubcategory(i, experienceYear);

					// 条件に一致する社員の年齢リストを追加
					Resume resume = resumeRepository.findByEmployeeEmployee_id(employeeList.get(i).getEmployee_id());

					if (resume != null) {

						ageList.add(resume.getAge());
					}
				}

				// 割合表示用処理
				percentage = "" + (int) (employeeList.size() / (float) employeeRepository.count() * 100) + "%";

				break;

			// 業種項目選択時 ===================================================
			case "industry":

				// 業務テーブルに指定業種が含まれる社員リストを返す
				employeeList = employeeRepository.findEmployeesByIndustryLike(analysisItemValue);

				for (int i = 0; i < employeeList.size(); i++) {

					List<Work> workList = workRepository.findByEmployeeId(employeeList.get(i).getEmployee_id());

					// 分析項目の業種に携わった合計期間を求める
					int totalPeriodMonth = 0;

					for (Work tempWork : workList) {

						// 業種が分析項目と一致するなら
						if (tempWork.getIndustry().contains(analysisItemValue)) {

							// 合計期間を取得 ※periodSumの記入フォーマットによって計算が違うため変更が必要かも(yymm仮定)
							String periodSum = tempWork.getPeriodSum();

							totalPeriodMonth += Integer.parseInt(periodSum.substring(0, 2)) * 12
									+ Integer.parseInt(periodSum.substring(2, 4));

						}
					}

					// グラフの副カテゴリに経験月数を追加
					addGraphSubcategory(i, totalPeriodMonth);

					// 条件に一致する社員の年齢リストを追加
					Resume resume = resumeRepository.findByEmployeeEmployee_id(employeeList.get(i).getEmployee_id());

					if (resume != null) {

						ageList.add(resume.getAge());
					}
				}
				break;

			// 資格項目選択時 ===================================================
			case "license":

				// 指定資格が資格カラムに含まれる社員データを取得
				employeeList = employeeRepository.findByAcquiredLicenseLike("%" + analysisItemValue + "%");

				for (int i = 0; i < employeeList.size(); i++) {

					// 習得資格の配列取得
					String[] acquiredLicenseArray = employeeList.get(i).getAcquiredLicense().split(",");

					// 分析項目に一致する資格が何年何月に受かったものかを取得
					String acquisitionDate = "";

					for (int j = 0; j < acquiredLicenseArray.length; j++) {

						if (acquiredLicenseArray[j].matches(analysisItemValue + ".*")) {

							acquisitionDate = acquiredLicenseArray[j].split("-")[1]; // yyyy/mmの形で取得

							break;
						}
					}

					// 現在の年月と取得年月の差を求める
					LocalDate currentDate = LocalDate.now();

					int yearDifference = currentDate.getYear() - Integer.parseInt(acquisitionDate.split("/")[0]);

					int monthDifference = currentDate.getMonthValue() - Integer.parseInt(acquisitionDate.split("/")[1]);

					int totalMonthDifference = (yearDifference * 12) + monthDifference;

					if ((totalMonthDifference % 12) > 6)

						yearDifference++; // 6ヶ月より離れている場合は差を1年増やす

					// グラフの副カテゴリに年を追加
					addGraphSubcategory(i, yearDifference);

					// 条件に一致する社員の年齢リストを追加
					Resume resume = resumeRepository.findByEmployeeEmployee_id(employeeList.get(i).getEmployee_id());

					if (resume != null) {

						ageList.add(resume.getAge());
					}
				}

				// 割合表示用処理
				percentage = "" + (int) (employeeList.size() / (float) employeeRepository.count() * 100) + "%";

				break;

			// 経験工程項目選択時 ===============================================
			case "process":

				// 指定経験工程が経験工程カラムに含まれる社員データを取得
				employeeList = employeeRepository.findAll();

				for (int i = employeeList.size() - 1; i > 0; i--) {

					// 業務リストを取得
					List<Work> workList = workRepository.findByEmployeeId(employeeList.get(i).getEmployee_id());

					for (int j = 0; j < workList.size(); j++) {

						// 開始と終了の経験工程を取得
						String processStart = workList.get(j).getProcess().split("-")[0];

						String processEnd = workList.get(j).getProcess().split("-")[1];

						int startIndex = processNameList.indexOf(processStart);

						int endIndex = processNameList.indexOf(processEnd);

						if (startIndex == -1 || endIndex == -1)

							continue;

						// 開始から終了までの経験工程を取得
						List<String> subList = processNameList.subList(startIndex, endIndex);

						// 条件に一致する経験工程が見つかった場合次の社員に移る
						if (subList.contains(analysisItemValue)) {

							break;
						}

						// 条件に一致する経験工程が無かった場合リストからデータを除外
						if (j >= workList.size() - 1) {

							employeeList.remove(i);
						}
					}
				}

				for (int i = 0; i < employeeList.size(); i++) {

					// グラフの副カテゴリに年を追加
					addGraphSubcategory(i, 0);

					// 条件に一致する社員の年齢リストを追加
					Resume resume = resumeRepository.findByEmployeeEmployee_id(employeeList.get(i).getEmployee_id());
					if (resume != null) {
						ageList.add(resume.getAge());
					}
				}

				// 割合表示用処理
				percentage = "" + (int) (employeeList.size() / (float) employeeRepository.count() * 100) + "%";

				break;

			// 選択肢以外 ===============================================	
			default:

				break;
			}

			// 作成したリストを渡す
			mav.addObject("languageNameList", languageNameList);

			mav.addObject("middlewareNameList", middlewareNameList);

			mav.addObject("industryNameList", industryNameList);

			mav.addObject("licenseNameList", licenseNameList);

			mav.addObject("processNameList", processNameList);

			mav.addObject("analysisResultsMap", analysisResultsMap);

			mav.addObject("percentage", percentage);

			mav.addObject("employeeDisplayInfoMap", employeeDisplayInfoMap);

			mav.addObject("ageList", ageList);

		} catch (Exception e) {

			//			mav.addObject("errorMsg", e);

			mav.addObject("errorMsg", "正常に分析処理が行えませんでした。");

			// 画面に出力するViewを指定
			mav.setViewName("A010_analysisList");

			return mav;
		}

		//		mav.addObject("errorMsg", "not found error");

		// 画面に出力するViewを指定
		mav.setViewName("A010_analysisList");

		return mav;

	}

	private String getAssignmentName(Employee employee) {
		// 所属名を取得
		Assignment assignment = assignmentRepository.findById(employee.getEmployee_id()).get();
		String departmentName = departmentRepository.findById(assignment.getDepartmentId()).get().getDepartment_name();
		String groupName = groupRepository.findById(assignment.getGroupId()).get().getGroup_name();
		String assignmentName = departmentName + "-" + groupName;

		return assignmentName;
	}

	/**
	  * 副カテゴリとして各カテゴリーに該当する社員のIDとその年月数を経験年数リストと社員情報リストに追加するメソッド。
	  * 
	  * @author 中野大希
	  * @param  employeeListIndex 指定されたカテゴリーに該当する社員のID。
	  * @param subcategoryValue 各カテゴリーの年月数。
	  * 
	  */

	private void addGraphSubcategory(int employeeListIndex, int subcategoryValue) {

		// 所属リスト取得
		ArrayList<Assignment> assignmentList = (ArrayList<Assignment>) assignmentRepository
				.findByEmployeeId(employeeList.get(employeeListIndex).getEmployee_id());

		String allAssignmentName = "";

		// 社員の所属に一致するkeyを探し、valueの経験年数リストに追加
		for (int j = 0; j < assignmentList.size(); j++) {

			Department department = departmentRepository.getReferenceById(assignmentList.get(j).getDepartmentId());

			Group group = groupRepository.getReferenceById(assignmentList.get(j).getGroupId());

			String assignmentName = department.getDepartment_name() + "-" + group.getGroup_name();

			allAssignmentName += assignmentName + ",";

			// 経験年数リストに追加
			if (analysisResultsMap.containsKey(assignmentName)) {

				List<Integer> tempExpYearList = analysisResultsMap.get(assignmentName);

				tempExpYearList.add(subcategoryValue);
			}

		}

		// 表示用の社員情報リストに部署-グループを追加
		allAssignmentName = allAssignmentName.substring(0, allAssignmentName.length() - 1);

		employeeDisplayInfoMap.put(employeeList.get(employeeListIndex), allAssignmentName);

	}

}