package com.example.employeeIntroduction.entity;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;

import lombok.Getter;
import lombok.Setter;

/**
 * 社員情報 Entity
 */

@Getter
@Setter


@Entity
@Table(name = "employee_info")
public class Employee implements Serializable {

	/**
	 * ID(主キー）
	 */
	@Id
	@Column(name = "employee_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int employee_id;

	/**
	 * 社員番号
	 */
	@Column(name = "employee_number")
	private int employee_number;

	/**
	 * 氏名
	 */
	@Column(name = "name", length = 200)
	private String name;

	/**
	 * 氏名（かな）
	 */
	@Column(name = "name_ruby", length = 200)
	private String name_ruby;

	/**
	 * 氏名（ローマ字）
	 */
	@Column(name = "name_alphabet", length = 200)
	private String name_alphabet;

	/**
	 * 開発経験年数
	 */
	@Column(name = "experience_year")
	private int experience_year;

	/**
	 * 社内メールアドレス
	 */
	@Column(name = "e_mail", length = 320)
	private String e_mail;

	/**
	 * 電話番号
	 */
	@Column(name = "phone_number", length = 30)
	private String phone_number;

	/**
	 * 生年月日
	 */
	@Column(name = "birth_date")
	@Temporal(TemporalType.DATE)
	private String birth_date;

	/**
	 * 入社年月
	 */
	@Column(name = "entry_date")
	@Temporal(TemporalType.DATE)
	private String entry_date;

	/**
	 * 資格
	 */


    @Column(name = "acquired_license", columnDefinition = "text")
    private String acquiredLicense;
	
	/**
	 * 習得言語
	 */
	
    @Column(name = "acquired_language", columnDefinition = "text")
    private String acquiredLanguage;
    
	/**
	 * 習得ミドルウェア
	 */
	
    @Column(name = "acquired_middleware", columnDefinition = "text")
    private String acquiredMiddleware;

	/**
	 * 趣味
	 */
	@Column(name = "hobby")
	private String hobby;

	/**
	 * 特技
	 */
	@Column(name = "talent")
	private String talent;

	/**
	 * 自己紹介
	 */
	@Column(name = "self_introduction")
	private String self_introduction;

	/**
	 * 写真
	 */
	@Column(name = "photo_path", length = 1000)
	private String photo_path;

	/**
	 * 権限番号
	 */
	//@ManyToOne(fetch = FetchType.LAZY)
	// @JoinColumn(name = "authority_id", referencedColumnName = "authority_id")
	@Column(name = "authority_id")
	private int authority_id;

	/**
	 * 採用ステータス
	 */
	@Column(name = "new_graduate_status")
	private int new_graduate_status;

	/**
	 * 雇用形態
	 */
	@Column(name = "employment_status")
	private int employment_status;

	/**
	 * 在職ステータス
	 */
	@Column(name = "tenure_status")
	private int tenure_status;

	/**
	 * 登録者
	 */
	
	@Column(name = "insert_person", length = 200)
	@CreatedBy
	private String insert_person;

	/**
	 * 更新者
	 */
	
	@Column(name = "update_person", length = 200)
	@LastModifiedBy
	private String update_person;

	/**
	 * 削除者
	 */
	
	@Column(name = "delete_person", length = 200)
	private String delete_person;

	/**
	 * 登録日
	 */
	
	@Column(name = "insert_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date insert_date;

	/**
	 * 更新日
	 */
	
	@Column(name = "update_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date update_date;

	/**
	 * 削除日
	 */
	
	@Column(name = "delete_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date delete_date;

	/**
	 * 退職日
	 */
	
	@Column(name = "retirement_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date retirement_date;

	/**
	 * 物理削除フラグ
	 */
	
	@Column(name = "delete_flg")
	private boolean delete_flg;
	
//	@OneToMany(mappedBy = "employee")
//    private Set<Assignment> assignments;
	
	

}
