package com.example.employeeIntroduction.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;

import lombok.Data;

/**
 * 部署情報 Entity
 */

@Entity
@Data
@Table(name = "department_info")
public class Department implements Serializable {

	/**
	 * 部署番号(主キー）
	 */
	@Id
	@Column(name = "department_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer department_id;

	/**
	 * 部署名
	 */
	@Column(name = "department_name")
	private String department_name;

	/**
	 * 非表示フラグ(0,表示1,非表示)
	 */
	@Column(name = "hide_flg")
	private boolean hide_flg = false;

	/**
	 * 物理削除フラグ(0,削除しない1,削除)
	 */
	@Column(name = "delete_flg")
	private boolean delete_flg = false;

	/**
	 * 表示優先順位(1~10想定)
	 */
	@Column(name = "display_priority")
	private int display_priority;

	/**
	 * 登録者（必須、最大200文字）
	 */
	@Column(name = "insert_person", length = 200)
	@CreatedBy
	private String insert_person;

	/**
	 * 更新者（必須、最大200文字）
	 */
	@Column(name = "update_person", length = 200)
	@LastModifiedBy
	private String update_person;

	/**
	 * 削除者（最大200文字）
	 */
	@Column(name = "delete_person", length = 200)
	private String delete_person;

	/**
	 * 登録日（必須）
	 */
	@Column(name = "insert_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date insert_date;

	/**
	 * 更新日（必須）
	 */
	@Column(name = "update_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date update_date;

	/**
	 * 削除日
	 */
	@Column(name = "delete_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date delete_date;

	/**
	 * この部署に関連するグループの集合。
	 * One-to-Manyのリレーションシップ
	 * 
	 */
	@OneToMany(mappedBy = "department")
	private Set<Group> groups;

}
