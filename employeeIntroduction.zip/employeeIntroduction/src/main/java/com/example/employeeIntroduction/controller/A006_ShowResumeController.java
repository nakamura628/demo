package com.example.employeeIntroduction.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.employeeIntroduction.entity.Resume;
import com.example.employeeIntroduction.entity.Work;
import com.example.employeeIntroduction.service.EmployeeService;
import com.example.employeeIntroduction.service.ResumeService;
import com.example.employeeIntroduction.service.WorkService;

@Controller
public class A006_ShowResumeController {

	@Autowired
	private ResumeService resumeService;
	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private WorkService workService;

	/**
	 * 指定された社員IDに基づいて、履歴書プレビュー画面を表示します。
	 * 社員情報、資格情報、業務経歴情報などをモデルに追加して、ビューに渡します。
	 *
	 * @author 岡田悠暉
	 * @param model ビューにデータを渡すためのModelオブジェクト
	 * @param employee_id 表示する社員のID（パス変数）
	 * @return 履歴書プレビュー画面のビュー名 ("A006_showResume")
	 */
	
	@GetMapping(value = "/resumePreview/{employee_id}")
	public String showResumePreview(Model model, @PathVariable Integer employee_id) {
		// 社員情報
		model.addAttribute("EmployeeNumber", employeeService.findById(employee_id).getEmployee_number());
		model.addAttribute("EmployeeName", employeeService.findById(employee_id).getName());

		// 技術経歴書情報
		Resume resume = resumeService.findById(employee_id); // Resumeの取得
		model.addAttribute("Initial", resume.getInitial());

		// 資格情報の取得
		model.addAttribute("IPALicense", resumeService.Extractionlicenses(employee_id, 0, 0));
		model.addAttribute("IPALicenseDate", resumeService.Extractionlicenses(employee_id, 0, 1));
		model.addAttribute("VendorLicense", resumeService.Extractionlicenses(employee_id, 1, 0));
		model.addAttribute("VendorLicenseDate", resumeService.Extractionlicenses(employee_id, 1, 1));
		model.addAttribute("OtherLicense", resumeService.Extractionlicenses(employee_id, 2, 0));
		model.addAttribute("OtherLicenseDate", resumeService.Extractionlicenses(employee_id, 2, 1));

		// 経験年数
		model.addAttribute("ExperiencePeriod", employeeService.getPeriodOfExperience(employee_id));

		// 年齢、性別、最寄駅
		model.addAttribute("Age", resume.getAge());
		model.addAttribute("Gender", resume.getGender());
		model.addAttribute("Station", resume.getStation());
		model.addAttribute("SelfPR", resume.getSelfPr());

		// 業務経歴情報の取得
		List<Work> works = workService.findByResumeId(resume.getResumeId());
		model.addAttribute("works", works);

		return "A006_showResume"; // 表示するビューを指定
	}

}
