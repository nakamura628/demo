package com.example.employeeIntroduction.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.employeeIntroduction.entity.Post;

/**
 * 役職情報に関するデータベース操作を行うリポジトリインターフェース。
 * JpaRepositoryを継承しており、標準的なCRUD操作に加えて、独自のクエリメソッドを提供します。
 * 
 * @author 中野大希、中村優介
 * 
 */

@Repository
public interface PostRepository extends JpaRepository<Post,Integer>{

	/**
	 * 全役職の名前を取得するメソッド。
	 * データベース内のすべての役職名をリストで返します。
	 *
	 * @author 中野大希
	 * @return 役職名のリスト
	 * 
	 */
	
	@Query("select p.post_name FROM Post p ")
	List<String> findPostName();
	
	}