package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import jakarta.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * リクエストをまとめた更新用DTOクラス
 * 
 */

@Data
@EqualsAndHashCode(callSuper=false)
public class EDGPAUpdateRequest  implements Serializable{
    @NotNull
    
    //社員情報
    private EmployeeUpdateRequest employeeUpdateRequest;
    
    //所属情報
    private AssignmentUpdateRequest assignmentUpdateRequest;
    
    

}
