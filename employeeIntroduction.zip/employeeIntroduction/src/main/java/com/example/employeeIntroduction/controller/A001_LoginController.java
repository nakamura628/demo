/**
 * EmployeeControllerクラスは、それぞれの機能の呼び出しをまとめたクラスです。
 * このクラスは、各機能に応じてServiceクラスやRepositoryクラス等にアクセスします。
 * 
 * @author　中村優介
 * @since 2024-07-17
 */

package com.example.employeeIntroduction.controller;

import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class A001_LoginController {

	/**
	 * ログインページの表示を担当するメソッド。
	 * 
	 * @author 小松莉久
	 * @return ログインページのビュー名を返す。
	 * 
	 */

	//ログイン画面へ
	@GetMapping("/login")
	public String login() {
		return "A001_login"; // ログインページのビュー名
	}

	/**
	 * ホーム画面への遷移を担当するメソッド。
	 * OAuth2認証情報に基づいてユーザーの名前やプロフィール画像をモデルに追加し、社員一覧画面にリダイレクトする。
	 * 
	 * @author 小松莉久
	 * @param model Modelオブジェクト。ビューに渡すデータを保持。
	 * @param authentication OAuth2AuthenticationTokenオブジェクト。認証情報を保持し、ユーザーのプロフィール情報にアクセスできる。
	 * @return 認証成功時は社員一覧画面へリダイレクトし、認証に失敗した場合はログイン画面を表示。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */

	@GetMapping("/home")
	public String home(Model model, OAuth2AuthenticationToken authentication) {
		try {

			if (authentication != null && authentication.getPrincipal() != null) {
				String userName = authentication.getPrincipal().getAttribute("name");
				String picture = authentication.getPrincipal().getAttribute("picture"); // プロフィール画像の取得
				model.addAttribute("username", userName);
				model.addAttribute("picture", picture); // モデルに画像を追加
				System.out.println("Username: " + userName); // デバッグ用のログ出力
				System.out.println("Picture: " + picture); // デバッグ用のログ出力
			} else {
				model.addAttribute("username", "Guest");
				System.out.println("Username: Guest"); // デバッグ用のログ出力

			}

		} catch (Exception e) {
			//			model.addAttribute("errorMsg", e);

			model.addAttribute("errorMsg", "正常にログインが行えませんでした。");

			return "A001_login";
		}
		//社員一覧画面へ遷移
		return "redirect:/employeeList";
	}

}