/**
 * EmployeeControllerクラスは、それぞれの機能の呼び出しをまとめたクラスです。
 * このクラスは、各機能に応じてServiceクラスやRepositoryクラス等にアクセスします。
 * 
 * @author　中村優介
 * @since 2024-07-17
 */

package com.example.employeeIntroduction.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.employeeIntroduction.entity.Assignment;
import com.example.employeeIntroduction.entity.Authority;
import com.example.employeeIntroduction.entity.Department;
import com.example.employeeIntroduction.entity.Employee;
import com.example.employeeIntroduction.entity.Group;
import com.example.employeeIntroduction.entity.Post;
import com.example.employeeIntroduction.repository.AssignmentRepository;
import com.example.employeeIntroduction.repository.AuthorityRepository;
import com.example.employeeIntroduction.repository.DepartmentRepository;
import com.example.employeeIntroduction.repository.GroupRepository;
import com.example.employeeIntroduction.repository.PostRepository;
import com.example.employeeIntroduction.service.EmployeeService;

@Controller
public class A003_ShowEmployeeDetailController {

	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private AssignmentRepository assignmentRepository;
	@Autowired
	private DepartmentRepository departmentRepository;
	@Autowired
	private GroupRepository groupRepository;
	@Autowired
	private PostRepository postRepository;
	@Autowired
	private AuthorityRepository authorityRepository;

//	@Autowired
//	private ResumeRepository resumeRepository;

	/**
	 * 指定された社員の詳細情報を表示するためのメソッド。
	 * 社員IDに基づき、社員の基本情報、所属情報、権限情報を取得し、画面に表示する。
	 * 
	 * @author 中村優介
	 * @param employee_id 表示対象の社員のID。
	 * @param model Modelオブジェクト。取得した社員の詳細情報を画面に渡すために使用。
	 * @param authentication OAuth2AuthenticationTokenオブジェクト。認証情報を使用してログイン中のユーザーの名前を取得。
	 * @return 社員詳細画面のビュー名を返す。エラー発生時は社員一覧画面にリダイレクト。
	 * @throws Exception データ取得や処理中にエラーが発生した場合にキャッチされ、エラーメッセージが返される。
	 * 
	 */

	@GetMapping("/showEmployeeDetail/{employee_id}")
	public String displayDetail(@PathVariable Integer employee_id, Model model,
			OAuth2AuthenticationToken authentication) {

		try {

			//ServiceクラスのfindByIdメソッドを呼び出し、戻り値をを代入する
			Employee employee = employeeService.findById(employee_id);

			//employee_idを引数として、リポジトリ経由で所属情報を取得
			ArrayList<Assignment> assignmentList = (ArrayList<Assignment>) assignmentRepository
					.findByEmployeeId(employee_id);

			//所属情報を用いて、部署、グループ、役職の必要な情報を取得する
			for (int i = 0; i < assignmentList.size(); i++) {

				//部署情報を所属テーブルの部署番号で参照
				Department department = departmentRepository
						.getReferenceById(assignmentList.get(i).getDepartmentId());

				//グループ情報を所属テーブルのグループ番号で参照
				Group group = groupRepository.getReferenceById(assignmentList.get(i).getGroupId());

				//役職情報を所属テーブルの役職番号で参照
				Post post = postRepository.getReferenceById(assignmentList.get(i).getPostId());

				//部署、グループ、役職の各名前を変数に格納
				String assignmentName = department.getDepartment_name() + "-" + group.getGroup_name() + "-"
						+ post.getPost_name();

				//パラメーターで画面に取得情報を渡す
				model.addAttribute("employeeData", employee);
				model.addAttribute("assignmentData", assignmentName);

			}

			//ボタン表示、非表示を判断するためにユーザー名を取得
			String userName = authentication.getPrincipal().getAttribute("name");

			//パラメーターで画面に取得情報を渡す
			model.addAttribute("userName", userName);

			//employee_idを引数として、リポジトリ経由で権限情報を取得
			Authority authority = authorityRepository.getReferenceById(employee.getAuthority_id());

			//パラメーターで画面に取得情報を渡す
			model.addAttribute("authority", authority);

			//		ArrayList<Resume> resumeList = (ArrayList<Resume>) resumeRepository
			//				.findByEmployeeId(employee_id);
			//
			//		for (int i = 0; i < resumeList.size(); i++) {
			//
			//			Resume resume = resumeRepository
			//					.getReferenceById(resumeList.get(i).getResumeId());
			//
			//			//パラメーターで画面に取得情報を渡す
			//			model.addAttribute("resume", resume);
			//		}

		} catch (Exception e) {

			//mav.addObject("errorMsg", e);

			//パラメーターで画面にエラー情報を渡す
			model.addAttribute("errorMsg", "正常に詳細情報を取得できませんでした。");

			//エラーが発生したら社員一覧へ戻る
			return "redirect:/employeeList";
		}

		//社員詳細画面へ遷移
		return "/A003_showEmployeeDetail";
	}

}