package com.example.employeeIntroduction.dto;

import java.io.Serializable;
import java.util.Date;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import lombok.Data;

/**
 * 画面から社員情報を格納するクラス
 * 
 */

@Data
public class EmployeeRequest implements Serializable {

	/**
	 * ID
	 */
	private int employee_id;

	/**
	 * 社員番号
	 */
	@NotEmpty(message = "社員番号を入力してください")
	@Pattern(regexp = "[0-9]*",message = "数字で入力してください")
	private int employee_number;

	/**
	 * 氏名
	 */
	@NotEmpty(message = "氏名を入力してください")
	@Size(max = 200, message = "200字以内で入力してください")
	private String name;

	/**
	 * 氏名（かな）
	 */
	@NotEmpty(message = "氏名（かな）を入力してください")
	@Size(max = 200, message = "200字以内で入力してください")
	private String name_ruby;

	/**
	 * 氏名（ローマ字）
	 */
	@NotEmpty(message = "氏名（ローマ字）を入力してください")
	@Size(max = 200, message = "200字以内で入力してください")
	private String name_alphabet;

	/**
	 * 社内メールアドレス
	 */
	@NotEmpty(message = "社内メールアドレスを入力してください")
	@Size(max = 320, message = "320字以内で入力してください")
	@Email(message = "電子メールアドレスとして正しい形式にしてください")
	private String e_mail;

	/**
	 * 入社年月
	 */
	@NotEmpty(message = "入社年月を入力してください")
	@PastOrPresent(message = "今日または過去の日付を入力してください")
	private String entry_date;
	
	/**
	 * 開発経験年数
	 */
	@NotEmpty(message = "開発経験年数を入力してください")
	private int experience_year;

	/**
	 * 電話番号
	 */
	@Pattern(regexp = "0\\d{1,4}-\\d{1,4}-\\d{4}", message = "電話番号の形式で入力してください")
	@Size(max = 30, message = "30桁以内で入力してください")
	private String phone_number;

	/**
	 * 生年月日
	 */
	@Past(message = "今日以前の日付を入力してください")
	private String birth_date;

	/**
	 * 資格
	 */
	private String acquired_license;

	/**
	 * 習得言語
	 */
	private String acquired_language;

	/**
	 * 習得ミドルウェア
	 */
	private String acquired_middleware;

	/**
	 * 趣味
	 */
	private String hobby;

	/**
	 * 特技
	 */
	private String talent;

	/**
	 * 自己紹介
	 */
	private String self_introduction;

	/**
	 * 写真
	 */
	@Size(max = 1000, message = "1000字以内のURLでアップロードしてください")
	private String photo_path;

	/**
	 * 権限番号
	 */
	private int authority_id;

	/**
	 * 採用ステータス
	 */
	private int new_graduate_status;

	/**
	 * 雇用形態
	 */
	private int employment_status;

	/**
	 * 在職ステータス
	 */
	private int tenure_status;

	/**
	 * 登録者
	 */
	@Size(max = 200, message = "200字以内で入力してください")
	private String insert_person;

	/**
	 * 更新者
	 */
	@Size(max = 200, message = "200字以内で入力してください")
	private String update_person;

	/**
	 * 削除者
	 */
	@Size(max = 200, message = "200字以内で入力してください")
	private String delete_person;

	/**
	 * 登録日
	 */
	private Date insert_date;

	/**
	 * 更新日
	 */
	private Date update_date;

	/**
	 * 削除日
	 */
	private Date delete_date;

	/**
	 * 退職日
	 */
	private String retirement_date;

	/**
	 * 物理削除フラグ
	 */
	private boolean delete_flg;

}
