package com.example.employeeIntroduction.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.employeeIntroduction.entity.Group;

/**
 * グループ情報に関するデータベース操作を行うリポジトリインターフェース。
 * JpaRepositoryを継承しており、標準的なCRUD操作に加えて、独自のクエリメソッドを提供します。
 * 
 * @author 中野大希、中村優介
 * 
 */

@Repository
public interface GroupRepository extends JpaRepository<Group, Integer> {

	/**
	 * 全グループの名前を取得するメソッド。
	 * データベース内のすべてのグループ名をリストで返します。
	 *
	 * @author 中野大希
	 * @return グループ名のリスト
	 * 
	 */

	@Query("select g.group_name FROM Group g ")
	List<String> findGroupName();

}