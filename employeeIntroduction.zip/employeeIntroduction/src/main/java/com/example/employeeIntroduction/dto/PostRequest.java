package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import lombok.Data;

/**
 * 部署情報を格納するクラス
 * 
 */

@Data
public class PostRequest implements Serializable {

	/**
	 * 役職番号
	 */
	private int post_id;
	
	/**
	 * 役職名
	 */
	private String post_name;
	
	/**
	 * 表示優先順位(1~10想定)
	 */
	private int display_priority;
	
	/**
	 * 登録者
	 */
	private String insert_person;
	
	/**
	 * 更新者
	 */
	private String update_person;	
	
	/**
	 * 削除者
	 */
	private String delete_person;	
	
	/**
	 * 登録日
	 */
	private String insert_date;	
	
	/**
	 * 更新日
	 */
	private String update_date;	
	
	/**
	 * 削除日
	 */
	private String delete_date;

}
