package com.example.employeeIntroduction.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class LicenseRequest implements Serializable {

	private int license_id;
	
	private String license_name;
	
	private int classification;
	
	private String insert_person;				
	
	private String update_person;				
	
	private String delete_person;				
	
	private String insert_date;				
	
	private String update_date;			
	
	private String delete_date;	
	
}
