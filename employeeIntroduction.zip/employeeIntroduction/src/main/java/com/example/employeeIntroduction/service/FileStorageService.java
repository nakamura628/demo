/**
 * FileStorageServiceクラスは、主に画像の保存処理を行うクラスです。
 * 画像URLの文字列をパスに変換し、生成したファイルにパスを保存し、
 * その保存した画像のURLをControllerクラスに返します。
 * 
 * @since 2024-07-30
 */

package com.example.employeeIntroduction.service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.Normalizer;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileStorageService {

	@Value("${file.upload-dir:uploads}") // プロパティファイルから読み込む

	//String型変数
	private String uploadDirPath;

	//パスを格納するための変数
	private Path uploadDir;

	/**
	 * 保存した画像のURLをコントローラーに返すメソッド。
	 * 
	 * @author 小松莉久
	 * @param file アップロードされた写真ファイル。{@link MultipartFile} オブジェクトとして受け取ります。
	 * @return 保存されたファイルのURL。
	 * @throws IOException ファイルの保存中やパスの異常でエラーが発生した場合にスローされます。
	 * 
	 */

	public String storeFile(MultipartFile file) throws IOException {

		//Stringをパスに変換する
		this.uploadDir = Paths.get(uploadDirPath);

		try {
			//パスがない場合
			if (!Files.exists(uploadDir)) {

				//パスのフォルダを生成
				Files.createDirectories(uploadDir);
			}

			//パスに異常がある場合
		} catch (IOException e) {
			throw new RuntimeException("アップロードディレクトリの作成に失敗しました", e);
		}

		// ファイル名の取得

		//アップロードされたファイル名の変数
		String originalFileName = file.getOriginalFilename();

		// ファイル名のサニタイズとユニーク化
		String sanitizedFileName = sanitizeFilename(originalFileName);

		//ランダムな文字を連結したファイルを格納する変数
		String fileName = UUID.randomUUID().toString() + "_" + sanitizedFileName;

		//新しいファイルパスを格納する変数
		Path filePath = uploadDir.resolve(fileName);

		// ファイルの保存
		try (InputStream inputStream = file.getInputStream()) {
			Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);

		} catch (IOException e) {
			throw e; // 再スローして呼び出し元にエラーを伝える
		}

		// ディレクトリ内のファイル一覧をコンソール確認する用の出力メソッド
		listFilesInDirectory();

		// 保存した画像のURLを返す
		return "/uploads/" + fileName;
	}

	/**
	 * ファイル名をサニタイズし、不正な文字を取り除くメソッド。
	 * 
	 * @author 小松莉久
	 * @param filename 元のファイル名
	 * @return サニタイズされたファイル名
	 * 
	 */

	private String sanitizeFilename(String filename) {
		// ファイル名を正規化して不正な文字を取り除く
		return Normalizer.normalize(filename, Normalizer.Form.NFKC)
				.replaceAll("[^a-zA-Z0-9._-]", "_");
	}

	/**
	 * 保存ディレクトリ内のファイル一覧をコンソールに出力するメソッド。
	 * ディレクトリ内にあるすべてのファイルの名前を表示します。
	 * 
	 * @author 小松莉久
	 */

	public void listFilesInDirectory() {
		try (DirectoryStream<Path> stream = Files.newDirectoryStream(uploadDir)) {
			for (Path entry : stream) {
				System.out.println("ディレクトリ内のファイル: " + entry.getFileName());
			}
		} catch (IOException e) {
			System.err.println("ディレクトリの読み取り中にエラーが発生しました: " + e.getMessage());
		}
	}

}
