/**
 * 
 */

document.addEventListener('DOMContentLoaded', function() {
	var background = document.getElementById('background');
	var now = new Date();
	var hours = now.getHours();

	if (hours >= 6 && hours < 12) {
		// 朝 6:00 - 11:59
		background.className = 'morning';
	} else if (hours >= 12 && hours < 18) {
		// 昼 12:00 - 17:59
		background.className = 'afternoon';
	} else if (hours >= 18 && hours < 21) {
		// 夕方 18:00 - 20:59
		background.className = 'evening';
	} else {
		// 夜 21:00 - 5:59
		background.className = 'night';
	}
});