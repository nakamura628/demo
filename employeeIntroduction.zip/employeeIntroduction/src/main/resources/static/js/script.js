/*<![CDATA[*/
var analysisResultsMap = /*[[${analysisResultsMap}]]*/ {};
var ageList = /*[[${ageList}]]*/ {};
var languageNameList = /*[[${languageNameList}]]*/ {};
var middlewareNameList = /*[[${middlewareNameList}]]*/ {};
var industryNameList = /*[[${industryNameList}]]*/ {};
var licenseNameList = /*[[${licenseNameList}]]*/ {};
var processNameList = /*[[${processNameList}]]*/ {};
/*]]>*/


var analysisItem = "";

function showSearchResult() {

	keywordArray.forEach(function(word) {
		addKeyword(word);
	});

	window.location.href = "/searchEmployeeResult?keyword=" + keyword;
}

function showEmployeeList() {
	window.location.href = "/searchEmployee";
}

function addKeyword(inputKeyword) {
	if (keyword != "") keyword += " - ";
	keyword += inputKeyword;
	let keywordElement = document.getElementById('keyword');

	keywordElement.innerHTML = keyword;
}

// フォーム作成
createSelect('language-select', languageNameList)
createSelect('middleware-select', middlewareNameList)
createSelect('industry-select', industryNameList)
createSelect('license-select', licenseNameList)
createSelect('process-select', processNameList)

function createSelect(selectId, itemNameList) {
	// セレクト要素取得
	let selectElement = document.getElementById(selectId);
	selectElement.setAttribute('name', selectId);
	selectElement.setAttribute('onchange', 'determineAnalysisItem("' + selectId + '")');

	selectElement.style.fontSize = "18px";
	selectElement.style.textAlign = "center";


	// option項目追加
	let selectOption = document.createElement('option');
	selectOption.setAttribute('value', 'default');
	selectOption.textContent = "選択してください";
	selectElement.appendChild(selectOption);

	itemNameList.forEach(item => {
		let selectOption = document.createElement('option');
		selectOption.setAttribute('value', item);
		selectOption.textContent = item;
		selectElement.appendChild(selectOption);
	});
}

// デバッグ用データ表示
let analysisResult = document.getElementById("analysisResult");
let str = "";
Object.entries(analysisResultsMap).forEach(([key, value]) => {
	str += key + "=" + value.length + ",<br>";
});
analysisResult.innerHTML += str;

// セレクトボックス選択イベント
function determineAnalysisItem(selectId) {
	let selectElement = document.getElementById(selectId);
	analysisItem = selectId.split("-")[0];
	analysisItem += "=" + selectElement.value;
	window.location.href = "/analysisListResult?analysisItem=" + analysisItem;
}

// グラフ作成
var assignmentGraphData = {
	labels: [],
	datasets: [
		{
			label: '０～３年',
			hoverBackgroundColor: "rgba(255,99,132,0.3)",
			data: [],
		},
		{
			label: '３～６年',
			hoverBackgroundColor: "rgba(54,162,235,0.3)",
			data: [],
		},
		{
			label: '６～９年',
			hoverBackgroundColor: "rgba(75,192,192,0.3)",
			data: [],
		},
		{
			label: '１０年以上',
			hoverBackgroundColor: "rgba(153,102,255,0.3)",
			data: [],
		}
	]
};

var ageGraphData = {
	labels: ["10代", "20代", "30代", "40代", "50代", "60歳以上"],
	datasets: [
		{
			label: '年齢別人数',
			hoverBackgroundColor: "rgba(255,99,132,0.3)",
			data: [],
		}
	]
};


//「オプション設定」
var options = {
	responsive: true,
	plugins: {
		title: {
			display: true,
			text: '人数分布'
		}
	},
	scales: {
		y: {
			beginAtZero: true,
			ticks: {
				stepSize: 1
			},
			min: 0,
			max: 10
		}

	}
};
// analysisResultsMapの中身をグラフに反映
Object.entries(analysisResultsMap).forEach(([key, value]) => {

	assignmentGraphData.labels.push(key);

	// 経験年数ごとの人数取得
	let bar1Cnt = 0, bar2Cnt = 0, bar3Cnt = 0, bar4Cnt = 0;
	value.forEach(function(item) {
		if (item < 3) bar1Cnt++;
		else if (item < 6) bar2Cnt++;
		else if (item < 9) bar3Cnt++;
		else bar4Cnt++;
	});

	assignmentGraphData.datasets[0].data.push(bar1Cnt);
	assignmentGraphData.datasets[1].data.push(bar2Cnt);
	assignmentGraphData.datasets[2].data.push(bar3Cnt);
	assignmentGraphData.datasets[3].data.push(bar4Cnt);
});


let bar1Cnt = 0, bar2Cnt = 0, bar3Cnt = 0, bar4Cnt = 0, bar5Cnt = 0, bar6Cnt = 0;

// ageListの中身をグラフに反映
ageList.forEach(function(age) {

	if (age < 20) bar1Cnt++;
	else if (age < 30) bar2Cnt++;
	else if (age < 40) bar3Cnt++;
	else if (age < 50) bar4Cnt++;
	else if (age < 60) bar5Cnt++;
	else bar6Cnt++;

});

ageGraphData.datasets[0].data.push(bar1Cnt);
ageGraphData.datasets[0].data.push(bar2Cnt);
ageGraphData.datasets[0].data.push(bar3Cnt);
ageGraphData.datasets[0].data.push(bar4Cnt);
ageGraphData.datasets[0].data.push(bar5Cnt);
ageGraphData.datasets[0].data.push(bar6Cnt);

// グラフ作成
var assignmentGraphCanvas = document.getElementById('assignmentGraph');
var chart = new Chart(assignmentGraphCanvas, {

	type: 'bar',
	data: assignmentGraphData,
	options: options,

});
var ageGraphCanvas = document.getElementById('ageListGraph');
var chart = new Chart(ageGraphCanvas, {

	type: 'bar',
	data: ageGraphData,
	options: options

});
