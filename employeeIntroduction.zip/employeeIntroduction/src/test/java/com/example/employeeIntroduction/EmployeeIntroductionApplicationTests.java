package com.example.employeeIntroduction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeIntroductionApplicationTests {

	@Test
	void contextLoads() {
	}

}
